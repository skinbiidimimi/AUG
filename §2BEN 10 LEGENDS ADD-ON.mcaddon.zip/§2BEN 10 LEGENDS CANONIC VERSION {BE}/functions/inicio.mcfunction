summon spw:inicio

gamerule sendcommandfeedback false

replaceitem entity @p slot.weapon.mainhand 1 id:menu1 1 0 {"item_lock":{"mode":"lock_in_slot"}}

dialogue open @e[type=spw:inicio,c=1] @p inicio
