xp -35l
effect @s clear 
function off_pw
clear @s md:omnitrix_comfiguracao
clear @s md:omnitrix_destruir
clear @s md:omnitrix_add_alien
clear @s md:omnitrix_recalibrar
clear @s m:massa
clear @s zx:misions
clear @s o:offc2
clear @s o:omnitrix 
replaceitem entity @s slot.armor.head 1 o:sistem_recalibrar
schedule delay add sistem_recalibrar 1s

playsound omnitrix.omn_cl_recalibration @a ~ ~ ~