kill spw:missoes
summon spw:dnalien
summon spw:dnalien
summon spw:dnalien
summon spw:dnalien
summon spw:dnalien
summon spw:dnalien

say os dnaliens voltaram derrote todos!