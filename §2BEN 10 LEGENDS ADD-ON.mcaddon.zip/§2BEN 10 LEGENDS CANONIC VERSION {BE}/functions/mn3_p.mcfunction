clear @p 

say Selecione seu modo 

give @p id:menu1 1 0 {"item_lock":{"mode":"lock_in_slot"}}