clear @s albedo:diamante4a
clear @s albedo:estrela4a
clear @s albedo:rath4a
clear @s albedo:ame4a
clear @s albedo:amf4a
clear @s albedo:arma4a
clear @s albedo:tarta4a
clear @s albedo:net4a 
clear @s albedo:net24a 
clear @s albedo:net34a 
clear @s albedo:off4a 
clear @s o:omnitrix4a
replaceitem entity @s slot.armor.head 1 albedo:amf4a 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s pw:power_amf 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s albedo:off4a 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tran3 @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans ~-1 ~ ~

effect @s water_breathing infinite 4 true
effect @s invisibility infinite 99 true
effect @s jump_boost infinite 2 true
effect @s health_boost infinite 5 true
effect @s instant_health 2 25 true

replaceitem entity @s slot.weapon.offhand 1 zx:amf_fp 1 0 {"item_lock":{"mode":"lock_in_slot"}}