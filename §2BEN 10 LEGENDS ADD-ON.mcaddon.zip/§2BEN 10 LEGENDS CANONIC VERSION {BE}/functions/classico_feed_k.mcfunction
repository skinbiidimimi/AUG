clear @s classico:frank_k 
clear @s classico:iden_k 
clear @s classico:mega_k 
clear @s classico:glut_k 
clear @s classico:giga_k 
clear @s classico:feed_k 
clear @s classico:contra_k 
clear @s classico:net 
clear @s classico:net2
clear @s classico:net3
clear @s classico:net4
clear @s classico:off 
clear @s classico:omnitrix_k
replaceitem entity @s slot.armor.head 1 classico:feed_k 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s pw:power_raio 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s classico:off 1 0 {"item_lock":{"mode":"lock_in_slot"}}

playsound omnitrix.tran @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans ~-1 ~ ~

effect @s invisibility infinite 10 true
effect @s jump_boost infinite 1 true
effect @s strength infinite 0 true
effect @s health_boost infinite 8 true
effect @s instant_health 2 25 true

replaceitem entity @s slot.weapon.offhand 1 zx:feed_fp 1 0 {"item_lock":{"mode":"lock_in_slot"}}