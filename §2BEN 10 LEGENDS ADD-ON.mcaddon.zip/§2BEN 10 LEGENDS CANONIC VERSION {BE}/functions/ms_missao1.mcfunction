kill spw:missoes
summon spw:drones
summon spw:drones
summon spw:drones

say derrote todos drones do vilgax !