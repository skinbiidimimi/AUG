clear @s c:chama
clear @s b:besta
clear @s d:diamante
clear @s x:xlr8
clear @s m:massa
clear @s q:quatro
clear @s i:inseq
clear @s o:omnitrix
clear @s o:offc2
clear @s u:ultra
clear @s n:net
give @s a:aquatico 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s u:ultra 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s f:fanta 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s[lm=3] b:bala 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s[lm=6] s:sipo_s 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s[lm=9] l:lob 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s[lm=12] b:mumia 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s o:offc2 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s[lm=15] n:net2 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

replaceitem entity @s slot.armor.head 1 o:omnitrix 1 0 {"item_lock":{"mode":"lock_in_slot"}}

playsound omnitrix.car @a ~ ~ ~
