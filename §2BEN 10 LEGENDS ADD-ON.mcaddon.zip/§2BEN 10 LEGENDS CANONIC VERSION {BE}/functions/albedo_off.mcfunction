function off_pw
function off_fp
clear @s albedo:fogo
clear @s albedo:eco
clear @s albedo:eno
clear @s albedo:arraia
clear @s albedo:friagen
clear @s albedo:cro
clear @s albedo:atro
clear @s albedo:maca
clear @s albedo:gosma
clear @s albedo:alien
clear @s albedo:bala
clear @s albedo:glut
clear @s albedo:giga
clear @s albedo:nano
clear @s albedo:diamante
clear @s albedo:rath
clear @s albedo:estrela
clear @s albedo:fanta
clear @s albedo:net
clear @s albedo:net2
clear @s albedo:off
clear @s o:omnitrix2a
give @s o:omnitrix2a

playsound omnitrix.des2 @a ~ ~ ~

particle ben:des ~ ~1 ~
particle ben:des ~ ~-1 ~
particle ben:des ~ ~ ~1
particle ben:des ~ ~1 ~-1
particle ben:des ~1 ~ ~
particle ben:des ~-1 ~ ~

replaceitem entity @s slot.armor.head 1 o:omnitrix2a 1 0 {"item_lock":{"mode":"lock_in_slot"}}