function off_pw
clear @s d:diamante3
clear @s e:estrela2
clear @s r:rath2
clear @s a:amf
clear @s a:ame
clear @s a:arma
clear @s t:tarta
clear @s n:nets
clear @s n:nets2
clear @s n:nets3
clear @s n:nets4
clear @s o:offc4
clear @s o:omnitrix3
replaceitem entity @p slot.armor.head 1 d:diamante3 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @p pw:espinhos2 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @p o:offc4 1 0 {"item_lock":{"mode":"lock_in_slot"}}

playsound omnitrix.tranaf @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans ~-1 ~ ~

effect @s fire_resistance 99999 3 true
effect @s invisibility infinite 99 true
effect @s jump_boost infinite 2 true
effect @s strength infinite 1 true
effect @s health_boost infinite 7 true
effect @s instant_health 2 25 true