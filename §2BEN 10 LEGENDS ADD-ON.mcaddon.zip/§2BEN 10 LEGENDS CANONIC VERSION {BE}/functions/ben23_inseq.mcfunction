clear @s o:omnitrix23
clear @s ben23:chama
clear @s ben23:besta
clear @s ben23:diamante
clear @s ben23:xlr8
clear @s ben23:massa
clear @s ben23:quatro
clear @s ben23:inseq
clear @s ben23:off
clear @s ben23:net
clear @s ben23:net2
replaceitem entity @p slot.armor.head 1 ben23:inseq 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @p pw:gosma_acido 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @p ben23:off 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tran @a ~ ~ ~

particle ben:trans2 ~ ~1 ~
particle ben:trans2 ~ ~-1 ~
particle ben:trans2 ~ ~ ~1
particle ben:trans2 ~ ~1 ~-1
particle ben:trans2 ~1 ~ ~
particle ben:trans2 ~-1 ~ ~

effect @s invisibility infinite 10 true
effect @s jump_boost infinite 1 true
effect @s strength infinite 0 true
effect @s health_boost infinite 2 true
effect @s instant_health 1 10 true

replaceitem entity @s slot.weapon.offhand 1 zx:inseq_fp 1 0 {"item_lock":{"mode":"lock_in_slot"}}