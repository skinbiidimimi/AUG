clear @s classico:frank_k 
clear @s classico:iden_k 
clear @s classico:mega_k 
clear @s classico:glut_k 
clear @s classico:giga_k 
clear @s classico:feed_k 
clear @s classico:contra_k 
clear @s classico:net 
clear @s classico:net2
clear @s classico:net3
clear @s classico:net4
clear @s classico:off 
clear @s classico:omnitrix_k
give @s classico:fogo_k 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s classico:eco_k 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s classico:eno_k 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s classico:arraia_k 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s classico:fria_k 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s classico:cro_k 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s classico:atro_k 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s classico:net4 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s classico:off 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.car @a ~ ~ ~