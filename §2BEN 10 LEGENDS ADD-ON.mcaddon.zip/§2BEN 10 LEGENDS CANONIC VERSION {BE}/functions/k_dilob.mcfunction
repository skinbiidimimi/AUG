clear @s k:glutao_g
clear @s k:quatro_enormo
clear @s k:gosmo_sauro
clear @s k:atomico
clear @s k:quatromumia
clear @s k:franklob
clear @s k:dilob
clear @s k:cra
clear @s o:offd3
clear @s o:offd4
clear @s o:offd2
clear @s o:bioomnitrix
replaceitem entity @s slot.armor.head 1 k:dilob 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s pw:espinhos2 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s pw:power_som 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s o:offd2 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.om4trans @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans ~-1 ~ ~

effect @s resistance infinite 0 true
effect @s regeneration infinite 0 true
effect @s fire_resistance infinite 5 true
effect @s invisibility infinite 10 true
effect @s jump_boost infinite 0 true
effect @s strength infinite 1 true
effect @s health_boost infinite 6 true
effect @s instant_health 1 10 true