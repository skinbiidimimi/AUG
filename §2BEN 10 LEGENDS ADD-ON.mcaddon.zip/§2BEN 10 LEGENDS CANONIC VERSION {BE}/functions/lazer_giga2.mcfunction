particle ben:som2 ~ ~1 ~
particle ben:som2 ~ ~-1 ~
particle ben:som2 ~ ~ ~1
particle ben:som2 ~ ~1 ~-1
particle ben:som2 ~1 ~ ~
particle ben:som2 ~-1 ~ ~