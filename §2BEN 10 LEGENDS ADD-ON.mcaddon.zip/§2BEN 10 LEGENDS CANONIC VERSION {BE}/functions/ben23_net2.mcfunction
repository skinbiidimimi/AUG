function off_pw
clear @s o:omnitrix23
clear @s ben23:chama
clear @s ben23:besta
clear @s ben23:diamante
clear @s ben23:xlr8
clear @s ben23:massa
clear @s ben23:quatro
clear @s ben23:inseq
clear @s ben23:aqua
clear @s ben23:ultra
clear @s ben23:fanta
clear @s ben23:bala
clear @s ben23:frank
clear @s ben23:mega
clear @s ben23:glut
clear @s ben23:gigante
clear @s ben23:feed
clear @s ben23:iguana
clear @s ben23:blox
clear @s ben23:eno
clear @s ben23:gosma
clear @s ben23:fria
clear @s ben23:rath
clear @s ben23:nano
clear @s ben23:grava
clear @s ben23:off
clear @s ben23:net
clear @s ben23:net2
clear @s ben23:net3
give @s[lm=5] ben23:gigante 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s[lm=6] ben23:feed 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s[lm=7] ben23:iguana 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s[lm=8] ben23:blox 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s[lm=9] ben23:eno 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s[lm=10] ben23:gosma 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s[lm=11] ben23:fria 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s ben23:off 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s[lm=12] ben23:net3 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

replaceitem entity @s slot.armor.head 1 o:omnitrix23 1 0 {"item_lock":{"mode":"lock_in_slot"}}

playsound omnitrix.car @a ~ ~ ~