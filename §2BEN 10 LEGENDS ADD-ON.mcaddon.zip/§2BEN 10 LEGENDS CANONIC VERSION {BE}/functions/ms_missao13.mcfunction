kill spw:missoes
summon spw:albedo

say albedo voltou com um novo omnitrix derrote o novamente mas tome cuidado ele esta muito mais forte!