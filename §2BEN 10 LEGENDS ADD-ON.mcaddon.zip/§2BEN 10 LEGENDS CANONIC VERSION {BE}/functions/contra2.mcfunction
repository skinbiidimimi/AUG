function off_pw
clear @s n:nrg
clear @s a:ace
clear @s c:chamalien
clear @s s:shock
clear @s b:besouro
clear @s c:contra2
clear @s d:diab
clear @s n:nets
clear @s n:nets2
clear @s n:nets3
clear @s n:nets4
clear @s o:offc4
clear @s o:omnitrix3
replaceitem entity @p slot.armor.head 1 c:contra 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s pw:power_tempo 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @p o:offc2 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tran @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans ~-1 ~ ~

effect @s invisibility infinite 99 true
effect @s jump_boost infinite 2 true
effect @s strength infinite 0 true
effect @s health_boost infinite 8 true
effect @s instant_health 2 25 true

replaceitem entity @s slot.weapon.offhand 1 zx:contra_fp 1 0 {"item_lock":{"mode":"lock_in_slot"}}