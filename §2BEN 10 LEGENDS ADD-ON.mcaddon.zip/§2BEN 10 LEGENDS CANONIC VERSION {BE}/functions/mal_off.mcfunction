function off_pw
clear @s mal:chama
clear @s mal:diamante
clear @s mal:xlr8
clear @s mal:ultra
clear @s mal:fanta
clear @s mal:giga
clear @s mal:feed
clear @s mal:fogo
clear @s mal:eco
clear @s mal:eno
clear @s mal:cro
clear @s mal:atro
clear @s mal:gosma
clear @s mal:alien
clear @s mal:grava
clear @s mal:astro
clear @s mal:chocan
clear @s mal:atomico
clear @s mal:net
clear @s mal:net2
clear @s mal:off
clear @s o:maltrix
give @s o:maltrix

playsound omnitrix.des3 @a ~ ~ ~

particle ben:des ~ ~1 ~
particle ben:des ~ ~-1 ~
particle ben:des ~ ~ ~1
particle ben:des ~ ~1 ~-1
particle ben:des ~1 ~ ~
particle ben:des ~-1 ~ ~

replaceitem entity @s slot.armor.head 1 o:maltrix 1 0 {"item_lock":{"mode":"lock_in_slot"}}