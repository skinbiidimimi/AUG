effect @s clear
tp @s @e[type=zx:lap]
effect @e[type=spw:belicos_serena2] instant_damage 99 9 true
fill ~-20 240 ~-4 ~4 255 ~20 air
clear @p o:offc3
clear @p alien:off2
clear @p pw:talk2

tp @e[type=zx:lap] 0 0 0