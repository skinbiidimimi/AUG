kill spw:missoes
summon spw:ben5
summon spw:ben6

say conheça sua versão irada kkk derrote o ben irado, e pra isso voce tem uma ajudinha de um amigo!