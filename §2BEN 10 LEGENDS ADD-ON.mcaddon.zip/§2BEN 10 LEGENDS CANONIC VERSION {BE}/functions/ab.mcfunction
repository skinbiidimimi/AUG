give @p[tag=!ccc] id:menu1 1 0 {"item_lock":{"mode":"lock_in_slot"}}
tag @p[tag=!ccc] add ccc

gamerule showcoordinates true
gamerule keepinventory true
gamerule mobgriefing false
gamerule doimmediaterespawn true
