clear @s nega:chama
clear @s nega:xlr8
clear @s nega:ultra
clear @s nega:feed
clear @s nega:iden
clear @s nega:fogo
clear @s nega:eco
clear @s nega:net
clear @s nega:off
clear @s o:negatrix
replaceitem entity @s slot.armor.chest 1 elytra

replaceitem entity @s slot.armor.head 1 nega:eco 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s pw:power_eco 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s nega:off 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.des1 @a ~ ~ ~

particle ben:trans3 ~ ~1 ~
particle ben:trans3 ~ ~-1 ~
particle ben:trans3 ~ ~ ~1
particle ben:trans3 ~ ~1 ~-1
particle ben:trans3 ~1 ~ ~
particle ben:trans3 ~-1 ~ ~

effect @s invisibility infinite 10 true
effect @s jump_boost infinite 1 true
effect @s health_boost infinite 3 true
effect @s instant_health 1 10 true

replaceitem entity @s slot.weapon.offhand 1 zx:eco_fp 1 0 {"item_lock":{"mode":"lock_in_slot"}}