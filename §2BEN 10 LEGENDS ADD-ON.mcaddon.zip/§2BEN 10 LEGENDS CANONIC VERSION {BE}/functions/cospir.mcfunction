particle ben:gosma ~ ~1 ~
particle ben:gosma ~ ~-1 ~
particle ben:gosma ~ ~ ~1
particle ben:gosma ~ ~1 ~-1
particle ben:gosma ~1 ~ ~
particle ben:gosma ~-1 ~ ~