clear @s md:omnitrix_comfiguracao
clear @s md:omnitrix_destruir
clear @s md:omnitrix_add_alien
clear @s md:omnitrix_recalibrar
give @s[lm=7] md:omnitrix_add_alien
give @s[lm=8] pw:hakear1
give @s[lm=9] md:omnitrix_recalibrar
give @s md:omnitrix_destruir