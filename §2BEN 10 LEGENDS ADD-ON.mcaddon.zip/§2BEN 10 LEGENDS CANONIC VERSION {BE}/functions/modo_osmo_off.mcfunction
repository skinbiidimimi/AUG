function off_pw
clear @s modo:osmosiano
clear @s osmo:terra
clear @s osmo:areia
clear @s osmo:madeira
clear @s osmo:pedra
clear @s osmo:pedregulho
clear @s osmo:ferro
clear @s osmo:ouro
clear @s osmo:net
clear @s modo:osmo_off
clear @s osmo:esme
clear @s osmo:dia
clear @s osmo:obisidian
clear @s osmo:kevin
clear @s osmo:kevin2
give @s modo:osmosiano 