kill spw:missoes
summon spw:kayber

say kevin se trasformou em um uma nova mutação muito mais poderosa derrote o!