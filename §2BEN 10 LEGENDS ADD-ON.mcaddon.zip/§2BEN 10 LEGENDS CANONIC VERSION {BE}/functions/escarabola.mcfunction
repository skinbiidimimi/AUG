clear @s b:besouro4
clear @s b:blox
clear @s g:grava
clear @s c:crash
clear @s e:escarabola
clear @s w:walkatruta
clear @s f:fada
clear @s n:net40
clear @s n:net41
clear @s n:net42
clear @s n:net43
clear @s n:net44
clear @s n:net45
clear @s n:net46
clear @s n:net47
clear @s o:offd
clear @s o:omnitrix4
replaceitem entity @p slot.armor.head 1 e:escarabola 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s o:offd 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tran @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans ~-1 ~ ~

effect @s speed infinite 2 true
effect @s night_vision infinite 10 true
effect @s slow_falling infinite 5 true