particle ben:energia3 ~ ~1 ~
particle ben:trans ~ ~-1 ~
particle ben:energia3 ~ ~ ~1
particle ben:trans ~ ~1 ~-1
particle ben:energia3 ~1 ~ ~
particle ben:energia3 ~-1 ~ ~