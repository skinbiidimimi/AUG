gamerule sendcommandfeedback false

say §2selecionado!!! modo craft, escolha seu dna!!!

give @p dna:humano2 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @p dna:anodita2 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @p dna:osmo2 1 0 {"item_lock":{"mode":"lock_in_slot"}}

tp @e[type=spw:inicio] 0 0 0

clear @p id:menu1
clear @p id:menu2
clear @p id:menu3
