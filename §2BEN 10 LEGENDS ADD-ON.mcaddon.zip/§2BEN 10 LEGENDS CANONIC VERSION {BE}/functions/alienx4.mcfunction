clear @s i:iden4
clear @s i:inseq4
clear @s r:rath4
clear @s m:mega4
clear @s m:maca4
clear @s a:alien4
clear @s o:offd
clear @s n:net40
clear @s n:net41
clear @s n:net42
clear @s n:net43
clear @s o:omnitrix4
replaceitem entity @s slot.armor.chest 1 elytra

replaceitem entity @s slot.armor.head 1 a:alien4 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s pw:power_alien 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s o:offd 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tran @a ~ ~ ~

particle on:particula ~ ~1 ~
particle on:particula ~ ~-1 ~
particle on:particula ~ ~ ~1
particle on:particula ~ ~1 ~-1
particle on:particula ~1 ~ ~
particle on:particula ~-1 ~ ~

effect @s haste infinite 99 true
effect @s night_vision infinite 20 true
effect @s slow_falling infinite 5 true
effect @s fire_resistance infinite 5 true
effect @s invisibility infinite 99 true
effect @s resistance infinite 1 true
effect @s regeneration infinite 1 true
effect @s jump_boost infinite 1 true
effect @s strength infinite 15 true
effect @s health_boost infinite 70 true
effect @s instant_health 1 10 true

replaceitem entity @s slot.weapon.offhand 1 zx:alien_fp 1 0 {"item_lock":{"mode":"lock_in_slot"}}