function off_pw
clear @s n:nrg
clear @s a:ace
clear @s c:chamalien
clear @s s:shock
clear @s b:besouro
clear @s c:contra2
clear @s d:diab
clear @s n:nets
clear @s n:nets2
clear @s n:nets3
clear @s n:nets4
clear @s o:offc4
clear @s o:omnitrix3
replaceitem entity @s slot.armor.head 1 d:diab 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s o:offc4 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tranaf @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans ~-1 ~ ~

effect @s invisibility infinite 10 true
effect @s jump_boost infinite 1 true

replaceitem entity @s slot.weapon.offhand 1 zx:diab_fp 1 0 {"item_lock":{"mode":"lock_in_slot"}}