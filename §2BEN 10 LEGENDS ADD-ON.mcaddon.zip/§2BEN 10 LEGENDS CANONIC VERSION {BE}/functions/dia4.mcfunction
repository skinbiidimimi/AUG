clear @s c:chama4
clear @s b:besta4
clear @s d:diamante4
clear @s x:xlr84
clear @s m:massa4
clear @s q:quatro4
clear @s i:inseq4
clear @s n:net40
clear @s n:net41
clear @s n:net42
clear @s n:net43
clear @s n:net44
clear @s n:net45
clear @s n:net46
clear @s n:net47
clear @s o:offd
clear @s o:omnitrix4
replaceitem entity @s slot.armor.head 1 d:diamante4 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s pw:espinhos2 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s o:offd 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tran @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans ~-1 ~ ~

effect @s resistance infinite 0 true
effect @s regeneration infinite 0 true
effect @s fire_resistance infinite 5 true
effect @s invisibility infinite 10 true
effect @s jump_boost infinite 0 true
effect @s strength infinite 1 true
effect @s health_boost infinite 6 true
effect @s instant_health 1 10 true