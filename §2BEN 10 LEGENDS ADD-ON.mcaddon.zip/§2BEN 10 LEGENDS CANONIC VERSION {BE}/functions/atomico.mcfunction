clear @s a:atomico
clear @s p:podrao
clear @s v:vomp
clear @s n:net40
clear @s n:net41
clear @s n:net42
clear @s n:net43
clear @s n:net44
clear @s n:net45
clear @s n:net46
clear @s n:net47
clear @s o:offd
clear @s o:omnitrix4
replaceitem entity @s slot.armor.head 1 a:atomico 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s pw:power_atomico 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s o:offd 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tran @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans ~-1 ~ ~

effect @s invisibility infinite 10 true
effect @s jump_boost infinite 0 true
effect @s strength infinite 4 true
effect @s health_boost infinite 20 true
effect @s instant_health 1 10 true

replaceitem entity @s slot.weapon.offhand 1 zx:atomico_fp 1 0 {"item_lock":{"mode":"lock_in_slot"}}