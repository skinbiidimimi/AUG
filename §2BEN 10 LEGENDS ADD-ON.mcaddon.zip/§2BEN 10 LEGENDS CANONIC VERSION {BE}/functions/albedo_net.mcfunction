function off_pw
clear @s o:omnitrix2a
clear @s albedo:fogo
clear @s albedo:eco
clear @s albedo:eno
clear @s albedo:arraia
clear @s albedo:friagen
clear @s albedo:cro
clear @s albedo:atro
clear @s albedo:maca
clear @s albedo:gosma
clear @s albedo:alien
clear @s albedo:bala
clear @s albedo:glut
clear @s albedo:giga
clear @s albedo:nano
clear @s albedo:diamante
clear @s albedo:rath
clear @s albedo:estrela
clear @s albedo:fanta
clear @s albedo:off
clear @s albedo:net
clear @s albedo:net2
give @s albedo:maca 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s albedo:gosma 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s albedo:alien 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s albedo:bala 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s albedo:glut 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s albedo:giga 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s albedo:nano 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s albedo:off 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s albedo:net2 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.re @a ~ ~ ~