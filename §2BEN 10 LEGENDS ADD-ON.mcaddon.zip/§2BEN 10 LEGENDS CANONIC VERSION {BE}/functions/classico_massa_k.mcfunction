clear @s classico:chama_k 
clear @s classico:besta_k 
clear @s classico:dia_k 
clear @s classico:xlr8_k 
clear @s classico:massa_k 
clear @s classico:quatro_k 
clear @s classico:inseq_k 
clear @s classico:net 
clear @s classico:net2
clear @s classico:net3
clear @s classico:net4
clear @s classico:off 
clear @s classico:omnitrix_k
replaceitem entity @s slot.armor.head 1 classico:massa_k 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @p pw:power_bomba 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s classico:off 1 0 {"item_lock":{"mode":"lock_in_slot"}}

playsound omnitrix.tran @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans ~-1 ~ ~

effect @s invisibility infinite 99 true
effect @s jump_boost infinite 1 true