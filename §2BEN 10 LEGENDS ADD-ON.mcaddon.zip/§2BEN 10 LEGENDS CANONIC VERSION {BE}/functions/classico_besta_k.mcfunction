clear @s classico:chama_k 
clear @s classico:besta_k 
clear @s classico:dia_k 
clear @s classico:xlr8_k 
clear @s classico:massa_k 
clear @s classico:quatro_k 
clear @s classico:inseq_k 
clear @s classico:net 
clear @s classico:net2
clear @s classico:net3
clear @s classico:net4
clear @s classico:off 
clear @s classico:omnitrix_k
replaceitem entity @s slot.armor.head 1 classico:besta_k 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s pw:espinhos 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s classico:off 1 0 {"item_lock":{"mode":"lock_in_slot"}}

playsound omnitrix.tran @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans ~-1 ~ ~

effect @s blindness infinite 1 true
effect @s speed infinite 2 true
effect @s invisibility infinite 10 true
effect @s jump_boost infinite 1 true
effect @s strength infinite 0 true
effect @s health_boost infinite 4 true
effect @s instant_health 1 10 true

replaceitem entity @s slot.weapon.offhand 1 zx:besta_fp 1 0 {"item_lock":{"mode":"lock_in_slot"}}