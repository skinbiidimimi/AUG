kill spw:missoes
summon spw:albedo

say derrote todo o albedo!