clear @s nega:chama
clear @s nega:xlr8
clear @s nega:ultra
clear @s nega:feed
clear @s nega:iden
clear @s nega:fogo
clear @s nega:eco
clear @s nega:net
clear @s nega:off
clear @s o:negatrix
replaceitem entity @p slot.armor.head 1 nega:iden 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s pw:clone1 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @p nega:off 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.des1 @a ~ ~ ~

particle ben:trans3 ~ ~1 ~
particle ben:trans3 ~ ~-1 ~
particle ben:trans3 ~ ~ ~1
particle ben:trans3 ~ ~1 ~-1
particle ben:trans3 ~1 ~ ~
particle ben:trans3 ~-1 ~ ~

effect @s invisibility infinite 99 true
effect @s jump_boost infinite 2 true
effect @s health_boost infinite 4 true
effect @s instant_health 2 25 true

replaceitem entity @s slot.weapon.offhand 1 zx:iden_fp 1 0 {"item_lock":{"mode":"lock_in_slot"}}