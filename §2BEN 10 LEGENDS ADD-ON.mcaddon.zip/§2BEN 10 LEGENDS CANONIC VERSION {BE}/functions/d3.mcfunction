clear @s o:offd3
clear @s o:offd4
clear @s o:offd2
clear @s o:bioomnitrix
replaceitem entity @s slot.armor.head 1 o:bioomnitrix 1 0 {"item_lock":{"mode":"lock_in_slot"}}

give @s k:dilob 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s k:quatromumia 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s k:franklob 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s k:quatro_enormo 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s k:glutao_g 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s k:gosmo_sauro 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s k:cra 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s k:atomico 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s o:offd2 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.usar @a ~ ~ ~