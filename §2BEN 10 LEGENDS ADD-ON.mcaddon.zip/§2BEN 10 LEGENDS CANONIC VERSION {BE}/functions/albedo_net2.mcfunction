function off_pw
clear @s albedo:fogo
clear @s albedo:eco
clear @s albedo:eno
clear @s albedo:arraia
clear @s albedo:friagen
clear @s albedo:cro
clear @s albedo:atro
clear @s albedo:maca
clear @s albedo:gosma
clear @s albedo:alien
clear @s albedo:bala
clear @s albedo:glut
clear @s albedo:giga
clear @s albedo:nano
clear @s albedo:net
clear @s albedo:net2
clear @s albedo:off
clear @s o:omnitrix2a
give @s albedo:diamante 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s albedo:rath 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s albedo:estrela 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s albedo:fanta 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s albedo:off 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}


playsound omnitrix.re @a ~ ~ ~
