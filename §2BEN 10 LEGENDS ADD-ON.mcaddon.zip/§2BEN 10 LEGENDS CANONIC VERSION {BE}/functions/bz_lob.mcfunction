clear @s bz:bala
clear @s bz:mega
clear @s bz:mumia
clear @s bz:lob
clear @s bz:frank
clear @s bz:giga
clear @s bz:besouro
clear @s bz:net
clear @s bz:off
clear @s o:zombitrix
replaceitem entity @s slot.armor.head 1 bz:lob 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s pw:power_som 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s bz:off 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
playsound omnitrix.bztran @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans ~-1 ~ ~

effect @s speed infinite 2 true
effect @s invisibility infinite 10 true
effect @s jump_boost infinite 2 true
effect @s strength infinite 0 true
effect @s health_boost infinite 4 true
effect @s instant_health 1 10 true

replaceitem entity @s slot.weapon.offhand 1 zx:lob_fp 1 0 {"item_lock":{"mode":"lock_in_slot"}}