clear @s g10:aqua
clear @s g10:ultra
clear @s g10:fanta
clear @s g10:bala
clear @s g10:sipo
clear @s g10:giga
clear @s g10:gosma
clear @s g10:alien
clear @s g10:off
clear @s g10:net
clear @s o:omniguen
replaceitem entity @p slot.armor.head 1 g10:gosma 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s pw:power_gosma1 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @p g10:off 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tran @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans ~-1 ~ ~

effect @s slow_falling infinite 8 true
effect @s fire_resistance infinite 1 true
effect @s invisibility infinite 10 true
effect @s jump_boost infinite 1 true
effect @s regeneration infinite 1 true
effect @s health_boost infinite 2 true
effect @s instant_health 1 10 true

replaceitem entity @s slot.weapon.offhand 1 zx:gosma_fp 1 0 {"item_lock":{"mode":"lock_in_slot"}}