clear @p pw:talk2
clear @p alien:off2
clear @s m:maca2
clear @s g:gosma2
clear @s a:alien2
clear @s b:bala3
clear @s g:glut3
clear @s g:giga3
clear @s n:nano2
clear @s n:nets
clear @s n:nets2
clear @s n:nets3
clear @s n:nets4
clear @s o:offc4
clear @s o:omnitrix3
give @s alien:off2 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tran @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans ~-1 ~ ~

effect @s night_vision 99999 10 true