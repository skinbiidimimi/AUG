function off_pw
function off_fp
function supremo_2s
clear @s albedo:maca2 
clear @s albedo:gosma2 
clear @s albedo:alien2 
clear @s albedo:bala2 
clear @s albedo:glut2 
clear @s albedo:giga2 
clear @s albedo:nano2 
clear @s albedo:nets 
clear @s albedo:nets2
clear @s albedo:nets3
clear @s albedo:nets4
clear @s albedo:off2 
clear @s o:omnitrix3a
replaceitem entity @s slot.armor.head 1 albedo:besta2s 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s pw:espinhos 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s albedo:bala2 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s albedo:off2 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tranaf @a ~ ~ ~

particle off:particula ~ ~1 ~
particle off:particula ~ ~-1 ~
particle off:particula ~ ~ ~1
particle off:particula ~ ~1 ~-1
particle off:particula ~1 ~ ~
particle off:particula ~-1 ~ ~

effect @s blindness infinite 1 true
effect @s speed infinite 3 true
effect @s invisibility infinite 10 true
effect @s jump_boost infinite 1 true
effect @s strength infinite 0 true
effect @s health_boost infinite 6 true
effect @s instant_health 1 10 true