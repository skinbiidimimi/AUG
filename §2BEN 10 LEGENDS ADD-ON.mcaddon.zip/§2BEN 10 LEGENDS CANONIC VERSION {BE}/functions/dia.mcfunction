clear @s c:chama
clear @s b:besta
clear @s d:diamante
clear @s x:xlr8
clear @s m:massa
clear @s q:quatro
clear @s a:aquatico
clear @s i:inseq
clear @s f:fanta
clear @s o:omnitrix
clear @s o:offc2
clear @s n:net
replaceitem entity @s slot.armor.head 1 d:diamante 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s pw:espinhos2 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s o:offc2 1 0 {"item_lock":{"mode":"lock_in_slot"}}

playsound omnitrix.tran @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans ~-1 ~ ~

effect @s resistance infinite 0 true
effect @s regeneration infinite 0 true
effect @s fire_resistance infinite 5 true
effect @s invisibility infinite 10 true
effect @s jump_boost infinite 0 true
effect @s strength infinite 1 true
effect @s health_boost infinite 6 true
effect @s instant_health 1 10 true

replaceitem entity @s slot.weapon.offhand 1 zx:diamante_fp 1 0 {"item_lock":{"mode":"lock_in_slot"}}