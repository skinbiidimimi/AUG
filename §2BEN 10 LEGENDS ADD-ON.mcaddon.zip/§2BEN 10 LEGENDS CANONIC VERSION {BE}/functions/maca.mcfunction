clear @s m:maca
clear @s g:gosma
clear @s a:alien
clear @s b:bala2
clear @s g:glut2
clear @s g:giga2
clear @s n:nano
clear @s n:netr
clear @s n:netr2
clear @s o:offc3
clear @s o:omnitrix2
replaceitem entity @p slot.armor.head 1 m:maca 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s pw:power_maca 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @p o:offc3 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.maca @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans ~-1 ~ ~

effect @s slow_falling infinite 9 true
effect @s invisibility infinite 99 true
effect @s jump_boost infinite 2 true
effect @s strength infinite 1 true
effect @s health_boost infinite 6 true
effect @s instant_health 2 25 true

replaceitem entity @s slot.weapon.offhand 1 zx:maca_fp 1 0 {"item_lock":{"mode":"lock_in_slot"}}