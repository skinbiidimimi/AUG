summon zx:lap

fill ~-20 ~100 ~-4 ~4 ~115 ~20 bedrock hollow