kill spw:missoes
summon spw:pet_hamister
summon spw:pet_chama
summon spw:pet_sapo
summon spw:dr_animal

say derrote o dr animal e os seus pets de estimação!