clear @p ben:roupa_ascalon
clear @p a:modo_ascal
replaceitem entity @p slot.armor.head 1 ben:roupa_ascalon
give @p esp:espada
give @p a:modo_ascal_off

effect @s resistance 99999 3 true
effect @s regeneration 99999 2 true
effect @s jump_boost 99999 3 true
effect @s strength 99999 4 true
effect @s health_boost 99999 40 true