clear @s m:maca
clear @s g:gosma
clear @s a:alien
clear @s b:bala2
clear @s g:glut2
clear @s g:giga2
clear @s n:nano
clear @s n:netr
clear @s n:netr2
clear @s o:offc3
clear @s o:omnitrix2
give @s alien:off 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tran @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans ~-1 ~ ~

effect @s night_vision infinite 90 true