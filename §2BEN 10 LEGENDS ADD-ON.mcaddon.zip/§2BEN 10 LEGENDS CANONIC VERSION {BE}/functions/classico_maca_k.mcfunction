clear @s classico:maca_k 
clear @s classico:gosma_k 
clear @s classico:alien_k 
clear @s classico:chocan_k 
clear @s classico:cosp_k 
clear @s classico:iguan_k 
clear @s classico:net 
clear @s classico:net2
clear @s classico:net3
clear @s classico:net4
clear @s classico:off 
clear @s classico:omnitrix_k
replaceitem entity @s slot.armor.head 1 classico:maca_k 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s pw:power_maca 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s classico:off 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
playsound omnitrix.tran @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans ~-1 ~ ~

effect @s slow_falling infinite 9 true
effect @s invisibility infinite 99 true
effect @s jump_boost infinite 2 true
effect @s strength infinite 1 true
effect @s health_boost infinite 6 true
effect @s instant_health 2 25 true

replaceitem entity @s slot.weapon.offhand 1 zx:maca_fp 1 0 {"item_lock":{"mode":"lock_in_slot"}}