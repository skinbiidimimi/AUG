summon pw:exp_bullet

kill @s
particle ben:trans ~ ~1 ~
particle ben:flame_atlas ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:flame_atlas ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:flame_atlas ~-1 ~ ~