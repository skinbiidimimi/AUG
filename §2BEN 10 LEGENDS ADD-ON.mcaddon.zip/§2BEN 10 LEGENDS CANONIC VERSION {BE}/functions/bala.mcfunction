clear @p a:aquatico
clear @p f:fanta
clear @p u:ultra
clear @p b:bala
clear @p s:sipo_s
clear @p l:lob
clear @p b:mumia
clear @p b:frank
clear @p o:omnitrix
clear @p o:offc2
clear @p n:net
clear @p n:net2
replaceitem entity @p slot.armor.head 1 b:bala 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s pw:power_ball1 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @p o:offc2 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tran @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans ~-1 ~ ~

effect @s invisibility infinite 1 true
effect @s jump_boost infinite 1 true
effect @s strength infinite 0 true
effect @s health_boost infinite 4 true
effect @s instant_health 1 10 true

replaceitem entity @s slot.weapon.offhand 1 zx:bala_fp 1 0 {"item_lock":{"mode":"lock_in_slot"}}