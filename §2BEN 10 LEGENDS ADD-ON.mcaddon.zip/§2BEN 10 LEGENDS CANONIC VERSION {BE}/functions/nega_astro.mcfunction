clear @s nega:eno
clear @s nega:cromatico
clear @s nega:gosma
clear @s nega:x 
clear @s nega:nano
clear @s nega:podrao
clear @s nega:astro
clear @s nega:atomico
clear @s nega:net
clear @s nega:off
clear @s o:negatrix
replaceitem entity @s slot.armor.chest 1 elytra

replaceitem entity @s slot.armor.head 1 nega:astro 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s pw:power_arraia 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s nega:off 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tran @a ~ ~ ~

particle ben:trans3 ~ ~1 ~
particle ben:trans3 ~ ~-1 ~
particle ben:trans3 ~ ~ ~1
particle ben:trans3 ~ ~1 ~-1
particle ben:trans3 ~1 ~ ~
particle ben:trans3 ~-1 ~ ~ 

effect @s slow_falling infinite 9 true
effect @s invisibility infinite 10 true
effect @s jump_boost infinite 2 true
effect @s strength infinite 0 true
effect @s health_boost infinite 4 true
effect @s instant_health 2 25 true

replaceitem entity @s slot.weapon.offhand 1 zx:astro_fp 1 0 {"item_lock":{"mode":"lock_in_slot"}}