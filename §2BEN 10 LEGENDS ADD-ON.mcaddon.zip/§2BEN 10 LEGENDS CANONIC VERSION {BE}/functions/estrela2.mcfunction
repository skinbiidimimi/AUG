function off_pw
clear @s d:diamante3
clear @s e:estrela2
clear @s r:rath2
clear @s a:amf
clear @s a:ame
clear @s a:arma
clear @s t:tarta
clear @s n:nets
clear @s n:nets2
clear @s n:nets3
clear @s n:nets4
clear @s o:offc4
clear @s o:omnitrix3
replaceitem entity @p slot.armor.head 1 e:estrela2 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s pw:power_estrela 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @p o:offc4 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tranaf @a ~ ~ ~

particle on:particula ~ ~1 ~
particle on:particula ~ ~-1 ~
particle on:particula ~ ~ ~1
particle on:particula ~ ~1 ~-1
particle on:particula ~1 ~ ~
particle on:particula ~-1 ~ ~

effect @s invisibility infinite 10 true
effect @s jump_boost infinite 2 true
effect @s health_boost infinite 5 true
effect @s instant_health 2 25 true

replaceitem entity @s slot.weapon.offhand 1 zx:estrela_fp 1 0 {"item_lock":{"mode":"lock_in_slot"}}