say selecionado §2DNA HUMANO!

clear @s dna:humano2
clear @s dna:anodita2
clear @s dna:osmo2