clear @s albedo:maca2 
clear @s albedo:gosma2 
clear @s albedo:alien2 
clear @s albedo:bala2 
clear @s albedo:glut2 
clear @s albedo:giga2 
clear @s albedo:nano2 
clear @s albedo:nets 
clear @s albedo:nets2
clear @s albedo:nets3
clear @s albedo:nets4
clear @s albedo:off2 
clear @s o:omnitrix3a
give @s o:omnitrix3a

playsound omnitrix.tranaf @a ~ ~ ~

say VOCE NÃO TEM ACESSO A ESSE ALIEN!
