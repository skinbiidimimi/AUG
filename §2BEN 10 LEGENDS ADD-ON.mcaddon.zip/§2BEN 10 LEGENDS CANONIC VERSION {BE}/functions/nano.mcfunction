clear @s m:maca
clear @s g:gosma
clear @s a:alien
clear @s b:bala2
clear @s g:glut2
clear @s g:giga2
clear @s n:nano
clear @s n:netr
clear @s n:netr2
clear @s o:offc3
clear @s o:omnitrix2
replaceitem entity @s slot.armor.chest 1 elytra

replaceitem entity @s slot.armor.head 1 n:nano 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @p pw:power_arraia 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @p o:offc3 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.nano @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans ~-1 ~ ~

effect @s slow_falling infinite 9 true
effect @s invisibility infinite 99 true
effect @s jump_boost infinite 2 true