clear @s m:maca
clear @s g:gosma
clear @s a:alien
clear @s b:bala2
clear @s g:glut2
clear @s g:giga2
clear @s n:nano
clear @s n:netr
clear @s n:netr2
clear @s o:offc3
clear @s o:omnitrix2
replaceitem entity @s slot.armor.head 1 g:giga2 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s pw:power_giga 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s o:offc3 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tranaf @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans ~-1 ~ ~

effect @s speed infinite 2 true
effect @s invisibility infinite 10 true
effect @s jump_boost infinite 2 true
effect @s strength infinite 8 true
effect @s health_boost infinite 25 true
effect @s instant_health 2 25 true

replaceitem entity @s slot.weapon.offhand 1 zx:giga_fp 1 0 {"item_lock":{"mode":"lock_in_slot"}}