function off_pw
clear @s bz:af
clear @s bz:blox
clear @s bz:grava
clear @s bz:atro
clear @s bz:alien
clear @s bz:net
clear @s bz:off
clear @s o:zombitrix
replaceitem entity @s slot.armor.head 1 bz:blox 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s pw:power_blox 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s bz:off 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tran @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans ~-1 ~ ~

effect @s invisibility infinite 99 true
effect @s jump_boost infinite 2 true
effect @s strength infinite 0 true
effect @s health_boost infinite 7 true
effect @s instant_health 2 25 true

replaceitem entity @s slot.weapon.offhand 1 zx:blox_fp 1 0 {"item_lock":{"mode":"lock_in_slot"}}