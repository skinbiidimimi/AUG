particle ben:laser_atomico ~ ~1 ~
particle ben:laser_atomico ~ ~-1 ~
particle ben:laser_atomico ~ ~ ~1
particle ben:laser_atomico ~ ~1 ~-1
particle ben:laser_atomico ~1 ~ ~
particle ben:laser_atomico ~-1 ~ ~