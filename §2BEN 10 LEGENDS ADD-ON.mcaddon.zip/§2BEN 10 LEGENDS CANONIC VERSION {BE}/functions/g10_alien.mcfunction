clear @s g10:aqua
clear @s g10:ultra
clear @s g10:fanta
clear @s g10:bala
clear @s g10:sipo
clear @s g10:giga
clear @s g10:gosma
clear @s g10:alien
clear @s g10:off
clear @s g10:net
clear @s o:omniguen
replaceitem entity @p slot.armor.head 1 g10:alien 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @p pw:espinhos4 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @p g10:off 1 0 {"item_lock":{"mode":"lock_in_slot"}}

playsound omnitrix.tran @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans ~-1 ~ ~

effect @s water_breathing infinite 4 true
effect @s invisibility infinite 99 true
effect @s jump_boost infinite 2 true
effect @s strength infinite 1 true