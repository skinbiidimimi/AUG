say selecionado §1DNA OSMOSIANO!

clear @s dna:humano2
clear @s dna:anodita2
clear @s dna:osmo2

give @s modo:osmosiano