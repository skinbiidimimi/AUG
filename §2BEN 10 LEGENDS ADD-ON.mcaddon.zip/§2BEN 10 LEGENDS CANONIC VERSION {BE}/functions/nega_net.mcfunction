clear @s o:negatrix
clear @s nega:chama
clear @s nega:xlr8
clear @s nega:ultra
clear @s nega:feed
clear @s nega:iden
clear @s nega:fogo
clear @s nega:eco
clear @s nega:off
clear @s nega:net
give @s nega:eno 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s nega:cromatico 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s nega:gosma 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s nega:x 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s nega:nano 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s nega:podrao 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s nega:astro 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s nega:atomico 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s nega:off 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.usar @a ~ ~ ~