particle ben:fura ~ ~1 ~
particle ben:fura ~ ~-1 ~
particle ben:fura ~ ~ ~1
particle ben:fura ~ ~1 ~-1
particle ben:fura ~1 ~ ~
particle ben:fura ~-1 ~ ~
