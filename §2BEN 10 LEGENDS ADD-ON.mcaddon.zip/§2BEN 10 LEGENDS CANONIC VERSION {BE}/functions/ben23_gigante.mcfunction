function off_pw
clear @s o:omnitrix23
clear @s ben23:chama
clear @s ben23:besta
clear @s ben23:diamante
clear @s ben23:xlr8
clear @s ben23:massa
clear @s ben23:quatro
clear @s ben23:inseq
clear @s ben23:aqua
clear @s ben23:ultra
clear @s ben23:fanta
clear @s ben23:bala
clear @s ben23:frank
clear @s ben23:mega
clear @s ben23:glut
clear @s ben23:gigante
clear @s ben23:feed
clear @s ben23:iguana
clear @s ben23:blox
clear @s ben23:eno
clear @s ben23:gosma
clear @s ben23:fria
clear @s ben23:rath
clear @s ben23:nano
clear @s ben23:grava
clear @s ben23:off
clear @s ben23:net
clear @s ben23:net2
clear @s ben23:net3
replaceitem entity @p slot.armor.head 1 ben23:gigante 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s pw:power_giga 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @p ben23:off 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tran @a ~ ~ ~

particle ben:trans2 ~ ~1 ~
particle ben:trans2 ~ ~-1 ~
particle ben:trans2 ~ ~ ~1
particle ben:trans2 ~ ~1 ~-1
particle ben:trans2 ~1 ~ ~
particle ben:trans2 ~-1 ~ ~

effect @s speed infinite 2 true
effect @s invisibility infinite 10 true
effect @s jump_boost infinite 2 true
effect @s strength infinite 8 true
effect @s health_boost infinite 25 true
effect @s instant_health 2 25 true

replaceitem entity @s slot.weapon.offhand 1 zx:giga_fp 1 0 {"item_lock":{"mode":"lock_in_slot"}}