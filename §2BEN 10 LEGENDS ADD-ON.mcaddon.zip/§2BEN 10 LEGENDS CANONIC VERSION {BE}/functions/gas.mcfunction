particle ben:gas2 ~ ~1 ~
particle ben:gas2 ~ ~-1 ~
particle ben:gas2 ~ ~ ~1
particle ben:gas2 ~ ~1 ~-1
particle ben:gas2 ~1 ~ ~
particle ben:gas2 ~-1 ~ ~