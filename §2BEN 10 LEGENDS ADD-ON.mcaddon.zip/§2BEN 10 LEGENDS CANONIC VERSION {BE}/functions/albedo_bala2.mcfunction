clear @s albedo:maca2 
clear @s albedo:gosma2 
clear @s albedo:alien2 
clear @s albedo:bala2 
clear @s albedo:glut2 
clear @s albedo:giga2 
clear @s albedo:nano2 
clear @s albedo:nets 
clear @s albedo:nets2
clear @s albedo:nets3
clear @s albedo:nets4
clear @s albedo:off2 
clear @s o:omnitrix3a
replaceitem entity @s slot.armor.head 1 albedo:bala2 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s pw:power_ball1 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s albedo:bala2s 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s albedo:off2 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tranaf @a ~ ~ ~

particle off:particula ~ ~1 ~
particle off:particula ~ ~-1 ~
particle off:particula ~ ~ ~1
particle off:particula ~ ~1 ~-1
particle off:particula ~1 ~ ~
particle off:particula ~-1 ~ ~

effect @s invisibility infinite 1 true
effect @s jump_boost infinite 1 true
effect @s strength infinite 0 true
effect @s health_boost infinite 4 true
effect @s instant_health 1 10 true

replaceitem entity @s slot.weapon.offhand 1 zx:bala_fp 1 0 {"item_lock":{"mode":"lock_in_slot"}}