kill spw:missoes
summon spw:kevin_supremo

say conheça maltruant um vilão muito poderoso tome cuidado!