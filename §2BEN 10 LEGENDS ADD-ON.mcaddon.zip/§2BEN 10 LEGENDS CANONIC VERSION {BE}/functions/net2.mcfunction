clear @s c:chama
clear @s b:besta
clear @s d:diamante
clear @s x:xlr8
clear @s m:massa
clear @s q:quatro
clear @s a:aquatico
clear @s o:omnitrix
clear @s o:offc2
clear @s n:net
clear @s i:inseq
clear @s u:ultra
clear @s f:fanta
clear @s b:bala
clear @s s:sipo_s
clear @s l:lob
clear @s b:mumia
clear @s b:frank
clear @s o:offc2
clear @s n:net2
give @s[lm=15] b:frank 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s[lm=18] i:iden 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s[lm=21] m:mega_o 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s[lm=24] g:glut 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s[lm=27] g:gigante 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s[lm=30] f:feed1 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s[lm=33] c:contra 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s o:offc2 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

replaceitem entity @s slot.armor.head 1 o:omnitrix 1 0 {"item_lock":{"mode":"lock_in_slot"}}

playsound omnitrix.car @a ~ ~ ~