clear @s c:chama2
clear @s b:besta2
clear @s q:quatro3
clear @s a:aquatico2
clear @s u:ultra2
clear @s f:fanta3
clear @s n:nets
clear @s n:nets2
clear @s n:nets3
clear @s n:nets4
clear @s o:offc4
replaceitem entity @s slot.armor.head 1 c:chama2 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s pw:power_fogo 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s o:offc4 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tranaf @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans ~-1 ~ ~

effect @s fire_resistance infinite 5 true
effect @s invisibility infinite 10 true
effect @s jump_boost infinite 0 true
effect @s strength infinite 0 true
effect @s health_boost infinite 5 true
effect @s instant_health 1 10 true

replaceitem entity @s slot.weapon.offhand 1 zx:chama_fp2 1 0 {"item_lock":{"mode":"lock_in_slot"}}