execute @s[tag=chakra_dimi] ~~~ scoreboard players remove @s chakra 1

execute @s[scores={chakra=0..1}] ~ ~ ~ tag @s remove chakra_mais

execute @s[scores={chakra=0..1}] ~ ~ ~ tag @s remove chakra_dimi

execute @s[scores={chakra=1504..1506}] ~ ~ ~ tag @s add chakra_mais

execute @s[scores={chakra=2499..2500}] ~ ~ ~ tag @s add chakra_mais

execute @s[scores={chakra=3499..3500}] ~ ~ ~ tag @s add chakra_mais

execute @s[scores={chakra=4999..5000}] ~ ~ ~ tag @s add chakra_mais

