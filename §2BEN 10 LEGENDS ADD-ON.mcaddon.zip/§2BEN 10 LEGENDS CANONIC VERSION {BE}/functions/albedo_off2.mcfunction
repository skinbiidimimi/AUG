function off_pw
function off_fp
function supremo_2s
clear @s albedo:fogo2 
clear @s albedo:eco2 
clear @s albedo:eno2 
clear @s albedo:arraia2 
clear @s albedo:friagen2 
clear @s albedo:cro2 
clear @s albedo:atro2 
clear @s albedo:maca2 
clear @s albedo:gosma2 
clear @s albedo:alien2 
clear @s albedo:bala2 
clear @s albedo:glut2 
clear @s albedo:giga2 
clear @s albedo:nano2 
clear @s albedo:diamante2 
clear @s albedo:estrela2 
clear @s albedo:rath2 
clear @s albedo:fanta2 
clear @s albedo:nets 
clear @s albedo:nets2
clear @s albedo:nets3
clear @s albedo:nets4
clear @s albedo:off2 
clear @s o:omnitrix3a
give @s o:omnitrix3a

playsound omnitrix.des2 @a ~ ~ ~

particle ben:des ~ ~1 ~
particle ben:des ~ ~-1 ~
particle ben:des ~ ~ ~1
particle ben:des ~ ~1 ~-1
particle ben:des ~1 ~ ~
particle ben:des ~-1 ~ ~

replaceitem entity @s slot.armor.head 1 o:omnitrix3a 1 0 {"item_lock":{"mode":"lock_in_slot"}}