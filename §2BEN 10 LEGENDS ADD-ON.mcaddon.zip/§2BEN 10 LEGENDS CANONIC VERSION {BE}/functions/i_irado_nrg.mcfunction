clear @s i:irado_nano
clear @s i:irado_rath
clear @s i:irado_estrela
clear @s i:irado_nrg
clear @s i:irado_cocor
clear @s i:irado_astro
clear @s i:irado_atomico
clear @s i:irado_net
clear @s i:irado_net2
clear @s i:irado_off
clear @s o:omnitrix_irado
replaceitem entity @s slot.armor.head 1 i:irado_nrg 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s pw:power_nrg 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s i:irado_off 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tran @a ~ ~ ~

particle ben:trans4 ~ ~1 ~
particle ben:trans4 ~ ~-1 ~
particle ben:trans4 ~ ~ ~1
particle ben:trans4 ~ ~1 ~-1
particle ben:trans4 ~1 ~ ~
particle ben:trans4 ~-1 ~ ~

effect @s fire_resistance infinite 3 true
effect @s invisibility infinite 10 true
effect @s strength infinite 1 true
effect @s health_boost infinite 7 true
effect @s instant_health 2 25 true

replaceitem entity @s slot.weapon.offhand 1 zx:nrg_fp 1 0 {"item_lock":{"mode":"lock_in_slot"}}