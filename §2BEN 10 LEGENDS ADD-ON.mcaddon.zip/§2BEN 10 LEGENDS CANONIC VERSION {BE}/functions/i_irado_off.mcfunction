function off_pw
clear @s i:irado_chama
clear @s i:irado_dia
clear @s i:irado_quatro
clear @s i:irado_ultra
clear @s i:irado_fanta
clear @s i:irado_bala
clear @s i:irado_glut
clear @s i:irado_giga
clear @s i:irado_feed
clear @s i:irado_eno
clear @s i:irado_cro
clear @s i:irado_atro
clear @s i:irado_gosma
clear @s i:irado_alien
clear @s i:irado_nano
clear @s i:irado_rath
clear @s i:irado_estrela
clear @s i:irado_nrg
clear @s i:irado_cocor
clear @s i:irado_astro
clear @s i:irado_atomico
clear @s i:irado_net
clear @s i:irado_net2
clear @s i:irado_off
clear @s o:omnitrix_irado
give @s o:omnitrix_irado

playsound omnitrix.des3 @a ~ ~ ~

particle ben:des ~ ~1 ~
particle ben:des ~ ~-1 ~
particle ben:des ~ ~ ~1
particle ben:des ~ ~1 ~-1
particle ben:des ~1 ~ ~
particle ben:des ~-1 ~ ~

replaceitem entity @s slot.armor.head 1 o:omnitrix_irado 1 0 {"item_lock":{"mode":"lock_in_slot"}}