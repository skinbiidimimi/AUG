kill spw:missoes
summon spw:ben5
summon spw:ben6

say esta acontecendo uma gerra omniversal ajude o bem a vencer o mal e protega sua variação sem omnitrix!!