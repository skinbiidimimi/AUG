gamerule sendcommandfeedback false

particle ben:fogo2 ~ ~1 ~
particle ben:fogo2 ~ ~-1 ~
particle ben:fogo2 ~ ~ ~1
particle ben:fogo2 ~ ~1 ~-1
particle ben:fogo2 ~1 ~ ~
particle ben:fogo2 ~-1 ~ ~

summon spw:robor ~~60~

say o robo gigante do vilgax esta vindo derrote-o!