function off_pw
clear @s albedo:diamante4a
clear @s albedo:estrela4a
clear @s albedo:rath4a
clear @s albedo:ame4a
clear @s albedo:amf4a
clear @s albedo:arma4a
clear @s albedo:tarta4a
clear @s albedo:net24a 
clear @s albedo:net34a 
clear @s albedo:net4a 
clear @s albedo:off4a 
clear @s o:omnitrix4a
give @s albedo:nrg4a 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s albedo:blox4a 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s albedo:grava4a 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s albedo:astro4a 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s albedo:cocor4a 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s albedo:atomico4a 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s albedo:podrao4a 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s albedo:vomp4a 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s albedo:off4a 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.car3 @a ~ ~ ~
