clear @s m:maca4
clear @s g:gosma4
clear @s a:alien4
clear @s g:glut5
clear @s n:nano4
clear @s r:rath4
clear @s e:estrela4
clear @s n:net40
clear @s n:net41
clear @s n:net42
clear @s n:net43
clear @s n:net44
clear @s n:net45
clear @s n:net46
clear @s n:net47
clear @s o:offd
clear @s o:omnitrix4
replaceitem entity @s slot.armor.head 1 g:gosma4 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s pw:power_gosma1 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s o:offd 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tran @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans ~-1 ~ ~

effect @s slow_falling infinite 8 true
effect @s fire_resistance infinite 1 true
effect @s invisibility infinite 10 true
effect @s jump_boost infinite 1 true
effect @s regeneration infinite 1 true
effect @s health_boost infinite 2 true
effect @s instant_health 1 10 true

replaceitem entity @s slot.weapon.offhand 1 zx:gosma_fp 1 0 {"item_lock":{"mode":"lock_in_slot"}}