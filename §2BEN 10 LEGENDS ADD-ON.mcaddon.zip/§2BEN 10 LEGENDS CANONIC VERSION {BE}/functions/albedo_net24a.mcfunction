function off_pw
clear @s albedo:maca4a
clear @s albedo:gosma4a
clear @s albedo:alien4a
clear @s albedo:bala4a
clear @s albedo:glut4a
clear @s albedo:giga4a
clear @s albedo:nano4a
clear @s albedo:net24a 
clear @s albedo:net34a 
clear @s albedo:net4a 
clear @s albedo:off4a 
clear @s o:omnitrix4a
give @s albedo:diamante4a 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s albedo:estrela4a 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s albedo:rath4a 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s albedo:ame4a 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s albedo:amf4a 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s albedo:arma4a 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s albedo:tarta4a 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s albedo:off4a 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s albedo:net34a 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.car3 @a ~ ~ ~
