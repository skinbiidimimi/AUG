clear @s a:aquatico4
clear @s u:ultra4
clear @s f:fanta4
clear @s b:bala4
clear @s s:sipo_s4
clear @s l:lob4
clear @s b:mumia4
clear @s n:net40
clear @s n:net41
clear @s n:net42
clear @s n:net43
clear @s n:net44
clear @s n:net45
clear @s n:net46
clear @s n:net47
clear @s o:offd
clear @s o:omnitrix4
replaceitem entity @s slot.armor.head 1 f:fanta4 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s pw:invi 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s o:offd 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tran @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans ~-1 ~ ~

effect @s night_vision infinite 10 true
effect @s slow_falling infinite 8 true
effect @s fire_resistance infinite 1 true
effect @s invisibility infinite 10 true
effect @s jump_boost infinite 1 true
effect @s strength infinite 0 true
effect @s health_boost infinite 4 true
effect @s instant_health 1 10 true

