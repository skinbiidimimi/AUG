say selecionado §5DNA ANODITA!

clear @s dna:humano2
clear @s dna:anodita2
clear @s dna:osmo2

give @s zx:livro_anodita