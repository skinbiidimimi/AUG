function off_pw
function off_fp
function albedo_off
clear @s albedo:maca
clear @s albedo:gosma
clear @s albedo:alien
clear @s albedo:bala
clear @s albedo:glut
clear @s albedo:giga
clear @s albedo:nano
clear @s albedo:net
clear @s albedo:net2
clear @s albedo:off
clear @s o:omnitrix2a
give @s o:omnitrix2a

playsound omnitrix.tranaf @a ~ ~ ~

say VOCE NÃO TEM ACESSO A ESSE ALIEN!
