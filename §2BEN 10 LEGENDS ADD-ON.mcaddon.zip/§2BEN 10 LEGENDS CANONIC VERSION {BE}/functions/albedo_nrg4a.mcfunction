clear @s albedo:nrg4a
clear @s albedo:blox4a
clear @s albedo:grava4a
clear @s albedo:astro4a
clear @s albedo:cocor4a
clear @s albedo:atomico4a
clear @s albedo:podrao4a
clear @s albedo:vomp4a
clear @s albedo:net4a 
clear @s albedo:net24a 
clear @s albedo:net34a 
clear @s albedo:off4a 
clear @s o:omnitrix4a
replaceitem entity @s slot.armor.head 1 albedo:nrg4a 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s pw:power_nrg 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s albedo:off4a 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tran3 @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans ~-1 ~ ~

effect @s fire_resistance infinite 3 true
effect @s invisibility infinite 10 true
effect @s strength infinite 1 true
effect @s health_boost infinite 7 true
effect @s instant_health 2 25 true

replaceitem entity @s slot.weapon.offhand 1 zx:nrg_fp 1 0 {"item_lock":{"mode":"lock_in_slot"}}