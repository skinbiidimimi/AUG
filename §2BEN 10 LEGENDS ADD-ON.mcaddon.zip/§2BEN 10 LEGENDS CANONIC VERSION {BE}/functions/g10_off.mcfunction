function off_pw
clear @s g10:chama
clear @s g10:besta
clear @s g10:dia
clear @s g10:xlr8
clear @s g10:massa
clear @s g10:quatro
clear @s g10:inseq
clear @s g10:aqua
clear @s g10:ultra
clear @s g10:fanta
clear @s g10:bala
clear @s g10:sipo
clear @s g10:giga
clear @s g10:gosma
clear @s g10:alien
clear @s g10:off
clear @s g10:net
clear @s o:omniguen
give @s o:omniguen
playsound omnitrix.des1 @a ~ ~ ~

particle ben:des ~ ~1 ~
particle ben:des ~ ~-1 ~
particle ben:des ~ ~ ~1
particle ben:des ~ ~1 ~-1
particle ben:des ~1 ~ ~
particle ben:des ~-1 ~ ~

replaceitem entity @s slot.armor.head 1 o:omniguen 1 0 {"item_lock":{"mode":"lock_in_slot"}}
