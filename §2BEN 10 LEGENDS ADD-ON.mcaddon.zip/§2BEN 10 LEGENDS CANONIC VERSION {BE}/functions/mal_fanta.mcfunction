clear @s mal:chama
clear @s mal:diamante
clear @s mal:xlr8
clear @s mal:ultra
clear @s mal:fanta
clear @s mal:giga
clear @s mal:feed
clear @s mal:net
clear @s mal:net2
clear @s mal:off
clear @s o:maltrix
replaceitem entity @p slot.armor.chest 1 elytra

replaceitem entity @p slot.armor.head 1 mal:fanta 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s pw:invi 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @p mal:off 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tran @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans2 ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans2 ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans2 ~-1 ~ ~

effect @s night_vision infinite 9 true
effect @s slow_falling infinite 9 true
effect @s fire_resistance infinite 3 true
effect @s invisibility infinite 99 true
effect @s jump_boost infinite 2 true
effect @s strength infinite 1 true
effect @s health_boost infinite 7 true
effect @s instant_health 2 25 true