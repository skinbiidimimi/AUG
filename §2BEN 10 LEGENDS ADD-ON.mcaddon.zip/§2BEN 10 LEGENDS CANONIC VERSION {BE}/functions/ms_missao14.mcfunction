kill spw:missoes
summon spw:agregor

say um novo inimigo apareceu chamado agregor derrote o!