clear @s o:bioomnitrix
replaceitem entity @s slot.armor.head 1 o:bioomnitrix 1 0 {"item_lock":{"mode":"lock_in_slot"}}

give @s o:offd3 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s o:offd4 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s o:offd2 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.usar @a ~ ~ ~