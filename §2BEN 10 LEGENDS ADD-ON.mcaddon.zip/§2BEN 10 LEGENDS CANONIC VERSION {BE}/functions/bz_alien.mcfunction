function off_pw
clear @s bz:af
clear @s bz:blox
clear @s bz:grava
clear @s bz:atro
clear @s bz:alien
clear @s bz:net
clear @s bz:off
clear @s o:zombitrix
replaceitem entity @p slot.armor.head 1 bz:alien
give @s pw:power_alien 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s bz:off 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tran @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans ~-1 ~ ~

effect @s haste infinite 99 true
effect @s night_vision infinite 20 true
effect @s slow_falling infinite 5 true
effect @s fire_resistance infinite 5 true
effect @s invisibility infinite 99 true
effect @s resistance infinite 1 true
effect @s regeneration infinite 1 true
effect @s jump_boost infinite 1 true
effect @s strength infinite 15 true
effect @s health_boost infinite 70 true
effect @s instant_health 1 10 true