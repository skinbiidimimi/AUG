kill spw:missoes
summon spw:dnalien
summon spw:dnalien
summon spw:dnalien
summon spw:dnalien
summon spw:dnalien
summon spw:dnalien

say derrote todo os dnaliens!