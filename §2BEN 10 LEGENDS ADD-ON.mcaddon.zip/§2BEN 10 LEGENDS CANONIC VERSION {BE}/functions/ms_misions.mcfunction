summon spw:missoes

dialogue open @e[type=spw:missoes,c=1] @p m_missoes

effect @e[type=spw:missoes] slowness 99 9 true