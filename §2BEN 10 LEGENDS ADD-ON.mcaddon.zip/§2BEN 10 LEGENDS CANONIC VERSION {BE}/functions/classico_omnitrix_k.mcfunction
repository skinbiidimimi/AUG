clear @s classico:omnitrix_k
replaceitem entity @s slot.armor.head 1 classico:omnitrix_k 1 0 {"item_lock":{"mode":"lock_in_slot"}}

give @s classico:chama_k 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s classico:besta_k 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s classico:dia_k 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s classico:xlr8_k 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s classico:massa_k 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s classico:quatro_k 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s classico:inseq_k 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s classico:net 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s classico:off 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.car @a ~ ~ ~