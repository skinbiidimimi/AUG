function off_pw
clear @s a:aquatico4
clear @s u:ultra4
clear @s f:fanta4
clear @s b:bala4
clear @s s:sipo_s4
clear @s l:lob4
clear @s b:mumia4
clear @s n:net40
clear @s n:net41
clear @s n:net42
clear @s n:net43
clear @s n:net44
clear @s n:net45
clear @s n:net46
clear @s n:net47
clear @s o:offd
clear @s o:omnitrix4
give @s[lm=15] b:frank4 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s[lm=18] i:iden4 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s[lm=21] m:mega_o4 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s[lm=24] g:glut4 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s[lm=27] g:giga4 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s[lm=30] f:feed 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s[lm=33] c:contra4 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s o:offd 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s[lm=36] n:net42 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.usar @a ~ ~ ~
