particle ben:iguana ~ ~1 ~
particle ben:iguana ~ ~-1 ~
particle ben:iguana ~ ~ ~1
particle ben:iguana ~ ~1 ~-1
particle ben:iguana ~1 ~ ~
particle ben:iguana ~-1 ~ ~