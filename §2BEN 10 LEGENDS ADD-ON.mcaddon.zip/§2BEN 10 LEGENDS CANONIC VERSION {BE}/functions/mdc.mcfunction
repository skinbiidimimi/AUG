clear @p i:inicio

