gamerule sendcommandfeedback false

say §2selecione a sua variação!!!!

give @p zx:inicio 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @p zx:inicio2 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @p zx:inicio3 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @p zx:inicio4 1 0 {"item_lock":{"mode":"lock_in_slot"}}

tp @e[type=spw:inicio] 0 0 0

gamemode adventure 

clear @p id:menu1
clear @p id:menu2
clear @p id:menu3
