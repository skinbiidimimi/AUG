summon pw:exp_bullet
