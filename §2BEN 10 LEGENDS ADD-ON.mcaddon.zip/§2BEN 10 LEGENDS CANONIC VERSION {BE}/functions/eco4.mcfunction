clear @s f:fogo4
clear @s e:eco4
clear @s e:eno4
clear @s a:arraia4
clear @s f:friagen4
clear @s c:cro4
clear @s a:atro4
clear @s n:net40
clear @s n:net41
clear @s n:net42
clear @s n:net43
clear @s n:net44
clear @s n:net45
clear @s n:net46
clear @s n:net47
clear @s o:offd
clear @s o:omnitrix4
replaceitem entity @s slot.armor.head 1 e:eco4 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s pw:power_eco 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s o:offd 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tran @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans ~-1 ~ ~

effect @s invisibility infinite 10 true
effect @s jump_boost infinite 1 true
effect @s health_boost infinite 3 true
effect @s instant_health 1 10 true

replaceitem entity @s slot.weapon.offhand 1 zx:eco_fp 1 0 {"item_lock":{"mode":"lock_in_slot"}}