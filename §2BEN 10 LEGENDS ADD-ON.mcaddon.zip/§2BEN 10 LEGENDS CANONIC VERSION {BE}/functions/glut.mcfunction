clear @p b:frank
clear @p g:glut
clear @p i:iden
clear @p m:mega_o
clear @p g:gigante
clear @p f:feed1
clear @p c:contra
clear @p o:omnitrix
clear @p o:offc2
clear @p n:net2
replaceitem entity @p slot.armor.head 1 g:glut 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s pw:power_glut 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @p o:offc2 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tran @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans ~-1 ~ ~

effect @s invisibility infinite 99 true
effect @s jump_boost infinite 2 true
effect @s health_boost infinite 4 true
effect @s instant_health 2 25 true

replaceitem entity @s slot.weapon.offhand 1 zx:glut_fp 1 0 {"item_lock":{"mode":"lock_in_slot"}}