clear @s c:chama4k 
clear @s b:besta4k 
clear @s d:diamante4k 
clear @s x:xlr84k 
clear @s m:massa4k 
clear @s q:quatro4k
clear @s i:inseq4k
clear @s n:net4k
clear @s o:offd3
clear @s o:offd4
clear @s o:offd2
clear @s o:bioomnitrix
replaceitem entity @s slot.armor.head 1 i:inseq4 4 4 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @p pw:gosma_acido 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s o:offd2 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tran @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans ~-1 ~ ~

effect @s invisibility infinite 10 true
effect @s jump_boost infinite 1 true
effect @s strength infinite 0 true
effect @s health_boost infinite 2 true
effect @s instant_health 1 10 true
