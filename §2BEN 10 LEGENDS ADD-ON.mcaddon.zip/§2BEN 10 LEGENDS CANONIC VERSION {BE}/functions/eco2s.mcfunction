function off_pw
function off_fp
function supremo_2s
clear @s f:fogo2
clear @s f:fogo2s
clear @s e:eco2
clear @s e:eno2
clear @s a:arraia2
clear @s f:friagen2
clear @s c:cro2
clear @s a:atro2 
clear @s n:nets
clear @s n:nets2
clear @s n:nets3
clear @s n:nets4
clear @s o:offc4
clear @s o:omnitrix3
replaceitem entity @s slot.armor.head 1 e:eco2s 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s pw:power_ecos 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s e:eco2 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s o:offc4 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tranaf @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans ~-1 ~ ~

effect @s invisibility infinite 99 true
effect @s jump_boost infinite 2 true
effect @s strength infinite 2 true
effect @s health_boost infinite 7 true
effect @s instant_health 2 25 true

replaceitem entity @s slot.weapon.offhand 1 zx:eco2s_fp 1 0 {"item_lock":{"mode":"lock_in_slot"}}