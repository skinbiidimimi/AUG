clear @s modo:osmosiano

give @s[lm=1]osmo:terra
give @s[lm=2] osmo:areia
give @s[lm=3] osmo:madeira
give @s[lm=4] osmo:pedra
give @s[lm=5] osmo:pedregulho
give @s[lm=6] osmo:ferro
give @s[lm=7] osmo:ouro
give @s[lm=8] osmo:net
give @s modo:osmo_off