clear @s bz:af
clear @s bz:blox
clear @s bz:grava
clear @s bz:atro
clear @s bz:alien
clear @s bz:net
clear @s bz:off
clear @s o:zombitrix
replaceitem entity @p slot.armor.head 1 bz:af 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @p pw:power_medo 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @p bz:off 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tran @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans ~-1 ~ ~

effect @s invisibility infinite 10 true
effect @s jump_boost infinite 1 true
effect @s strength infinite 1 true
effect @s health_boost infinite 4 true
effect @s instant_health 1 10 true