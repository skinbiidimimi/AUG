clear @s albedo:maca4a
clear @s albedo:gosma4a
clear @s albedo:alien4a
clear @s albedo:bala4a
clear @s albedo:glut4a
clear @s albedo:giga4a
clear @s albedo:nano4a
clear @s albedo:net4a 
clear @s albedo:net24a 
clear @s albedo:net34a 
clear @s albedo:off4a 
clear @s o:omnitrix4a
replaceitem entity @s slot.armor.head 1 albedo:maca4a 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s pw:power_maca 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s albedo:off4a 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tran3 @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans ~-1 ~ ~

effect @s slow_falling infinite 9 true
effect @s invisibility infinite 99 true
effect @s jump_boost infinite 2 true
effect @s strength infinite 1 true
effect @s health_boost infinite 6 true
effect @s instant_health 2 25 true

replaceitem entity @s slot.weapon.offhand 1 zx:maca_fp 1 0 {"item_lock":{"mode":"lock_in_slot"}}