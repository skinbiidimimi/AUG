function off_pw
clear @s m:maca2
clear @s g:gosma2
clear @s a:alien2
clear @s b:bala3
clear @s g:glut3
clear @s g:giga3
clear @s n:nano2
clear @s n:nets
clear @s n:nets2
clear @s n:nets3
clear @s n:nets4
clear @s o:offc4
clear @s o:omnitrix3
replaceitem entity @p slot.armor.head 1 g:glut3 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s pw:power_glut 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @p o:offc4 1 0 {"item_lock":{"mode":"lock_in_slot"}}

playsound omnitrix.tranaf @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans ~-1 ~ ~

effect @s invisibility infinite 99 true
effect @s jump_boost infinite 2 true
effect @s health_boost infinite 4 true
effect @s instant_health 2 25 true

replaceitem entity @s slot.weapon.offhand 1 zx:glut_fp 1 0 {"item_lock":{"mode":"lock_in_slot"}}