clear @s nega:chama
clear @s nega:xlr8
clear @s nega:ultra
clear @s nega:feed
clear @s nega:iden
clear @s nega:fogo
clear @s nega:eco
clear @s nega:net
clear @s nega:off
clear @s o:negatrix
replaceitem entity @p slot.armor.head 1 nega:xlr8 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @p v:v1 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @p pw:power_tornado 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
playsound omnitrix.des1 @a ~ ~ ~

particle ben:trans3 ~ ~1 ~
particle ben:trans3 ~ ~-1 ~
particle ben:trans3 ~ ~ ~1
particle ben:trans3 ~ ~1 ~-1
particle ben:trans3 ~1 ~ ~
particle ben:trans3 ~-1 ~ ~

effect @s haste infinite 90 true
effect @s invisibility infinite 10 true
effect @s jump_boost infinite 0 true
effect @s health_boost infinite 3 true
effect @s instant_health 1 10 true