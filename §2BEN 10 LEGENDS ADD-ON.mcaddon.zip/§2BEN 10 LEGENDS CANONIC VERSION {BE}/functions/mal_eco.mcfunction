clear @s mal:fogo
clear @s mal:eco
clear @s mal:eno
clear @s mal:cro
clear @s mal:atro
clear @s mal:gosma
clear @s mal:alien
clear @s mal:net
clear @s mal:net2
clear @s mal:off
clear @s o:maltrix
replaceitem entity @p slot.armor.head 1 mal:eco 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s pw:power_eco 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s mal:off 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tran @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans2 ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans2 ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans2 ~-1 ~ ~

effect @s invisibility infinite 10 true
effect @s jump_boost infinite 1 true
effect @s health_boost infinite 3 true
effect @s instant_health 1 10 true

replaceitem entity @s slot.weapon.offhand 1 zx:eco_fp 1 0 {"item_lock":{"mode":"lock_in_slot"}}