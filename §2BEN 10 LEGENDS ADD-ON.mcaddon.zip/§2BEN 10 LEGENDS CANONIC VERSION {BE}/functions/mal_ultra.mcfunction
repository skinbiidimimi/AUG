clear @s mal:chama
clear @s mal:diamante
clear @s mal:xlr8
clear @s mal:ultra
clear @s mal:fanta
clear @s mal:giga
clear @s mal:feed
clear @s mal:net
clear @s mal:net2
clear @s mal:off
clear @s o:maltrix
replaceitem entity @p slot.armor.head 1 mal:ultra 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s pw:power_lazer 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @p mal:off 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tran @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans2 ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans2 ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans2 ~-1 ~ ~

effect @s slow_falling infinite 2 true
effect @s invisibility infinite 10 true
effect @s jump_boost infinite 0 true
effect @s regeneration infinite 0 true
effect @s health_boost infinite 3 true
effect @s instant_health 1 10 true

replaceitem entity @s slot.weapon.offhand 1 zx:ultra_fp 1 0 {"item_lock":{"mode":"lock_in_slot"}}