say as missões acabaram, mais tera mai missões em breve

summon spw:ttrax