fill ~-1 ~-1 ~-1 ~1 ~-1 ~1 air

summon m:meteoro ~~20~

particle ben:fogo2 ~ ~1 ~
particle ben:fogo2 ~ ~-1 ~
particle ben:fogo2 ~ ~ ~1
particle ben:fogo2 ~ ~1 ~-1
particle ben:fogo2 ~1 ~ ~
particle ben:fogo2 ~-1 ~ ~
