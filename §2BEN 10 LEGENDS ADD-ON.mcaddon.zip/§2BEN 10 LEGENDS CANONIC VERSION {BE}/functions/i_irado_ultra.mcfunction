clear @s i:irado_chama
clear @s i:irado_dia
clear @s i:irado_quatro
clear @s i:irado_ultra
clear @s i:irado_fanta
clear @s i:irado_bala
clear @s i:irado_glut
clear @s i:irado_net
clear @s i:irado_net2
clear @s i:irado_off
clear @s o:omnitrix_irado
replaceitem entity @s slot.armor.head 1 i:irado_ultra 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s pw:power_lazer 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s i:irado_off 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tran @a ~ ~ ~

particle ben:trans4 ~ ~1 ~
particle ben:trans4 ~ ~-1 ~
particle ben:trans4 ~ ~ ~1
particle ben:trans4 ~ ~1 ~-1
particle ben:trans4 ~1 ~ ~
particle ben:trans4 ~-1 ~ ~

effect @s slow_falling infinite 2 true
effect @s invisibility infinite 10 true
effect @s jump_boost infinite 0 true
effect @s regeneration infinite 0 true
effect @s health_boost infinite 3 true
effect @s instant_health 1 10 true

replaceitem entity @s slot.weapon.offhand 1 zx:ultra_fp 1 0 {"item_lock":{"mode":"lock_in_slot"}}