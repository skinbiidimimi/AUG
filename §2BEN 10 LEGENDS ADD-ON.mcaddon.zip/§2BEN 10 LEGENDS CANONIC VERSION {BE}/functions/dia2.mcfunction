clear @p o:omnitrix2
clear @p o:offc3
clear @p n:netr
clear @p n:netr2
clear @p d:diamante2
clear @p e:estrela
clear @p r:rath
clear @p f:fanta2

replaceitem entity @p slot.armor.head 1 d:diamante2 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @p pw:espinhos2 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @p o:offc3 1 0 {"item_lock":{"mode":"lock_in_slot"}}

playsound omnitrix.tranaf @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans ~-1 ~ ~

effect @s resistance infinite 0 true
effect @s regeneration infinite 0 true
effect @s fire_resistance infinite 5 true
effect @s invisibility infinite 10 true
effect @s jump_boost infinite 0 true
effect @s strength infinite 1 true
effect @s health_boost infinite 6 true
effect @s instant_health 1 10 true