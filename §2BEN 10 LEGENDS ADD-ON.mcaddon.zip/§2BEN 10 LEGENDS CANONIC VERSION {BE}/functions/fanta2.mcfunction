clear @p o:omnitrix2
clear @p o:offc3
clear @p n:netr
clear @p n:netr2
clear @p d:diamante2
clear @p e:estrela
clear @p r:rath
clear @p f:fanta2
replaceitem entity @p slot.armor.head 1 f:fanta2 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s pw:invi 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @p o:offc3 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tranaf @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans ~-1 ~ ~

effect @s night_vision infinite 10 true
effect @s slow_falling infinite 8 true
effect @s fire_resistance infinite 1 true
effect @s invisibility infinite 10 true
effect @s jump_boost infinite 1 true
effect @s strength infinite 0 true
effect @s health_boost infinite 4 true
effect @s instant_health 1 10 true

