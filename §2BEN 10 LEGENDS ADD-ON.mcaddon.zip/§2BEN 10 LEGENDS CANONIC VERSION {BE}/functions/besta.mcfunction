clear @p c:chama
clear @p b:besta
clear @p d:diamante
clear @p x:xlr8
clear @p m:massa
clear @p q:quatro
clear @p a:aquatico
clear @p i:inseq
clear @p f:fanta
clear @p o:omnitrix
clear @p o:offc2
clear @p n:net
replaceitem entity @p slot.armor.head 1 b:besta 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @p pw:espinhos 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @p o:offc2 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tran @a ~ ~ ~

playanimation @s animation.besta.walk

particle ben:trans ~ ~1 ~
particle ben:trans ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans ~-1 ~ ~

effect @s blindness infinite 1 true
effect @s speed infinite 2 true
effect @s invisibility infinite 10 true
effect @s jump_boost infinite 1 true
effect @s strength infinite 0 true
effect @s health_boost infinite 4 true
effect @s instant_health 1 10 true
