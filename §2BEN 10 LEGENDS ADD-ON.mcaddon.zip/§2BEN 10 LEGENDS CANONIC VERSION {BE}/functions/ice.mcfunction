gamerule sendcommandfeedback false

setblock ~1~~ ice
setblock ~-1~~ ice
setblock ~~~1 ice
setblock ~~~-1 ice
setblock ~1~1~ ice
setblock ~-1~1~ ice
setblock ~~1~1 ice
setblock ~~1~-1 ice