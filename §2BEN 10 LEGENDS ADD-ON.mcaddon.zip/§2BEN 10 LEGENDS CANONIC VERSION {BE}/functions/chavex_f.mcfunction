function off_pw
effect @s clear
tp @s @e[type=zx:lap]
effect @e[type=spw:belicos_serena] instant_damage 99 9 true
fill ~-20 240 ~-4 ~4 255 ~20 air
clear @s pw:talk
clear @s alien:off

replaceitem entity @s slot.weapon.offhand 1 zx:alien_fp 1 0 {"item_lock":{"mode":"lock_in_slot"}}

tp @e[type=zx:lap] 0 0 0

say resposta errada!!! você voltou para o mundo normal!