effect @s clear 
clear @s md:omnitrix_comfiguracao
clear @s md:omnitrix_destruir
clear @s md:omnitrix_add_alien
clear @s md:omnitrix_recalibrar
clear @s m:massa
clear @s zx:misions
clear @s o:offc2
clear @s o:omnitrix















function  md_omnitrix_destruir2