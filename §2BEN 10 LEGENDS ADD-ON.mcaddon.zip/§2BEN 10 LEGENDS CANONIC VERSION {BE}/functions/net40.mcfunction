function off_pw
clear @s c:chama4
clear @s b:besta4
clear @s d:diamante4
clear @s x:xlr84
clear @s m:massa4
clear @s q:quatro4
clear @s i:inseq4
clear @s n:net40
clear @s n:net41
clear @s n:net42
clear @s n:net43
clear @s n:net44
clear @s n:net45
clear @s n:net46
clear @s n:net47
clear @s o:offd
clear @s o:omnitrix4
give @s a:aquatico4 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s u:ultra4 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s f:fanta4 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s[lm=3] b:bala4 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s[lm=6] s:sipo_s4 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s[lm=9] l:lob4 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s[lm=12] b:mumia4 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s o:offd 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s[lm=15] n:net41 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.usar @a ~ ~ ~