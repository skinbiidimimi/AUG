clear @s o:omniguen
clear @s g10:chama
clear @s g10:besta
clear @s g10:dia
clear @s g10:xlr8
clear @s g10:massa
clear @s g10:quatro
clear @s g10:inseq
clear @s g10:off
clear @s g10:net
clear @s o:omniguen
replaceitem entity @p slot.armor.head 1 g10:inseq 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @p pw:gosma_acido 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @p g10:off 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tran @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans ~-1 ~ ~

effect @s invisibility infinite 10 true
effect @s jump_boost infinite 1 true
effect @s strength infinite 0 true
effect @s health_boost infinite 2 true
effect @s instant_health 1 10 true

replaceitem entity @s slot.weapon.offhand 1 zx:inseq_fp 1 0 {"item_lock":{"mode":"lock_in_slot"}}