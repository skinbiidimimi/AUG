clear @s f:fogo
clear @s e:eco
clear @s e:eno
clear @s a:arraia
clear @s f:friagen 
clear @s c:cro
clear @s a:atro 
clear @s n:netr
clear @s n:netr2
clear @s o:offc3
clear @s o:omnitrix2
replaceitem entity @p slot.armor.chest 1 elytra

replaceitem entity @p slot.armor.head 1 a:arraia 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @p pw:power_arraia 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s o:offc3 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tranaf @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans ~-1 ~ ~

effect @s slow_falling infinite 5 true
effect @s invisibility infinite 10 true
effect @s jump_boost infinite 1 true
effect @s health_boost infinite 5 true
effect @s instant_health 2 25 true

replaceitem entity @s slot.weapon.offhand 1 zx:arraia_fp 1 0 {"item_lock":{"mode":"lock_in_slot"}}