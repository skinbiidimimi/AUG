clear @s mal:grava
clear @s mal:astro
clear @s mal:chocan
clear @s mal:atomico
clear @s mal:net
clear @s mal:net2
clear @s mal:off
clear @s o:maltrix
replaceitem entity @s slot.armor.chest 1 elytra

replaceitem entity @s slot.armor.head 1 mal:atomico 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s pw:power_atomico 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s mal:off 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tran @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans2 ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans2 ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans2 ~-1 ~ ~

effect @s invisibility infinite 10 true
effect @s jump_boost infinite 0 true
effect @s strength infinite 4 true
effect @s health_boost infinite 20 true
effect @s instant_health 1 10 true