clear @s classico:aqua_k 
clear @s classico:ultra_k 
clear @s classico:fanta_k 
clear @s classico:bala_k 
clear @s classico:sipo_k 
clear @s classico:lob_k 
clear @s classico:mumia_k 
clear @s classico:net 
clear @s classico:net2
clear @s classico:net3
clear @s classico:net4
clear @s classico:off 
clear @s classico:omnitrix_k
replaceitem entity @s slot.armor.head 1 classico:sipo_k 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @p pw:espinhos3_ss 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s classico:off 1 0 {"item_lock":{"mode":"lock_in_slot"}}

playsound omnitrix.tran @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans ~-1 ~ ~

effect @s invisibility infinite 10 true
effect @s jump_boost infinite 1 true
effect @s strength infinite 0 true
effect @s health_boost infinite 3 true
effect @s instant_health 1 10 true