clear @s i:irado_chama
clear @s i:irado_dia
clear @s i:irado_quatro
clear @s i:irado_ultra
clear @s i:irado_fanta
clear @s i:irado_bala
clear @s i:irado_glut
clear @s i:irado_net
clear @s i:irado_net2
clear @s i:irado_off
clear @s o:omnitrix_irado
give @s i:irado_giga 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s i:irado_feed 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s i:irado_eno 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s i:irado_cro 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s i:irado_atro 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s i:irado_gosma 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s i:irado_alien 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s i:irado_off 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s i:irado_net2 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.usar @a ~ ~ ~