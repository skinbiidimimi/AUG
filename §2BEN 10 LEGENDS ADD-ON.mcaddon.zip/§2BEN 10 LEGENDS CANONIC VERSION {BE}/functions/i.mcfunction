give @p[tag=!ccc] id:menu1
give @p[tag=!ccc] id
give @p[tag=!ccc] id:
tag @p[tag=!ccc] add ccc
