kill spw:missoes
summon spw:ben10

say albedo não se cansa, ele voltou de novo pra se exibir com o seu novo omnitrix mostre pra ele quem manda!!