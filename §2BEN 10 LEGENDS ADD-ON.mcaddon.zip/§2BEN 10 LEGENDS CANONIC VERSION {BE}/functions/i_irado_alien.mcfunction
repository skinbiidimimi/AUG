clear @s i:irado_giga
clear @s i:irado_feed
clear @s i:irado_eno
clear @s i:irado_cro
clear @s i:irado_atro
clear @s i:irado_gosma
clear @s i:irado_alien
clear @s i:irado_net
clear @s i:irado_net2
clear @s i:irado_off
clear @s o:omnitrix_irado
replaceitem entity @s slot.armor.head 1 i:irado_alien
give @s i:irado_off

playsound omnitrix.tran @a ~ ~ ~

particle ben:trans4 ~ ~1 ~
particle ben:trans4 ~ ~-1 ~
particle ben:trans4 ~ ~ ~1
particle ben:trans4 ~ ~1 ~-1
particle ben:trans4 ~1 ~ ~
particle ben:trans4 ~-1 ~ ~

effect @s invisibility infinite 99 true
