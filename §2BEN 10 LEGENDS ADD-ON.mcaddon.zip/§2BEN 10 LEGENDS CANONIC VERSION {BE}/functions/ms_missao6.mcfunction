kill spw:missoes
summon spw:kevin11

say derrote o kevin11!