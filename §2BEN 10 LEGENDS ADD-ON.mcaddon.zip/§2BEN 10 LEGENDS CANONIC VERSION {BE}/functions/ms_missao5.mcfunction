kill spw:missoes
summon spw:mumia
summon spw:frank
summon spw:lob
summon spw:fanta

say derrote o z,scar e sua gangue!