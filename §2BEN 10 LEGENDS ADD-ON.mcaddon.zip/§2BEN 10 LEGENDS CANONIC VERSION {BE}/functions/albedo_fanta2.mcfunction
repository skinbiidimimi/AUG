clear @s albedo:diamante2 
clear @s albedo:estrela2 
clear @s albedo:rath2 
clear @s albedo:fanta2 
clear @s albedo:nets 
clear @s albedo:nets2
clear @s albedo:nets3
clear @s albedo:nets4
clear @s albedo:off2 
clear @s o:omnitrix3a
replaceitem entity @s slot.armor.head 1 albedo:fanta2 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s pw:invi 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s albedo:off2 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tranaf @a ~ ~ ~

particle off:particula ~ ~1 ~
particle off:particula ~ ~-1 ~
particle off:particula ~ ~ ~1
particle off:particula ~ ~1 ~-1
particle off:particula ~1 ~ ~
particle off:particula ~-1 ~ ~

effect @s night_vision infinite 10 true
effect @s slow_falling infinite 8 true
effect @s fire_resistance infinite 1 true
effect @s invisibility infinite 10 true
effect @s jump_boost infinite 1 true
effect @s strength infinite 0 true
effect @s health_boost infinite 4 true
effect @s instant_health 1 10 true

