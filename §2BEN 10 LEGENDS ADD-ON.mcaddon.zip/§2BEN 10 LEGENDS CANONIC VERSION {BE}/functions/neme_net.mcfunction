clear @s o:nemetrix
replaceitem entity @s slot.armor.head 1 o:nemetrix 1 0 {"item_lock":{"mode":"lock_in_slot"}}

clear @s neme:alien1
clear @s neme:alien2
clear @s neme:alien3
clear @s neme:alien4
clear @s neme:alien5
clear @s neme:alien6
clear @s neme:alien7
clear @s neme:alien8
clear @s neme:alien9
clear @s neme:alien10
clear @s neme:off
clear @s neme:net
give @s neme:alien8 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s neme:alien9 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s neme:alien10 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s neme:off 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.usar @a ~ ~ ~