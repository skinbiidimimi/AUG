kill spw:missoes
summon spw:vilgax
summon spw:drones
summon spw:drones
summon spw:drones
summon spw:drones2
summon spw:drones2

say vilgax voltou com seus drones em busca do omnitrix derrote o!