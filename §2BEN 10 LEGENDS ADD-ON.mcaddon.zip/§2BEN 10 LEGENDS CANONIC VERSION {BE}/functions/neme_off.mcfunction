function off_pw
clear @s neme:alien1
clear @s neme:alien2
clear @s neme:alien3
clear @s neme:alien4
clear @s neme:alien5
clear @s neme:alien6
clear @s neme:alien7
clear @s neme:alien8
clear @s neme:alien9
clear @s neme:alien10
clear @s neme:net
clear @s neme:off
clear @s o:nemetrix
give @s o:nemetrix

playsound omnitrix.des1 @a ~ ~ ~

particle ben:des ~ ~1 ~
particle ben:des ~ ~-1 ~
particle ben:des ~ ~ ~1
particle ben:des ~ ~1 ~-1
particle ben:des ~1 ~ ~
particle ben:des ~-1 ~ ~

replaceitem entity @s slot.armor.head 1 o:nemetrix 1 0 {"item_lock":{"mode":"lock_in_slot"}}