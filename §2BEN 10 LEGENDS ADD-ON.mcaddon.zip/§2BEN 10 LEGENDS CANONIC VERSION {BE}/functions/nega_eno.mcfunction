clear @s nega:eno
clear @s nega:cromatico
clear @s nega:gosma
clear @s nega:x 
clear @s nega:nano
clear @s nega:podrao
clear @s nega:astro
clear @s nega:atomico
clear @s nega:net
clear @s nega:off
clear @s o:negatrix
replaceitem entity @p slot.armor.head 1 nega:eno 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s pw:power_eno 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @p nega:off 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.des1 @a ~ ~ ~

particle ben:trans3 ~ ~1 ~
particle ben:trans3 ~ ~-1 ~
particle ben:trans3 ~ ~ ~1
particle ben:trans3 ~ ~1 ~-1
particle ben:trans3 ~1 ~ ~
particle ben:trans3 ~-1 ~ ~

effect @s invisibility infinite 99 true
effect @s jump_boost infinite 2 true
effect @s strength infinite 2 true
effect @s slowness infinite 0 true
effect @s health_boost infinite 12 true
effect @s instant_health 2 25 true

replaceitem entity @s slot.weapon.offhand 1 zx:eno_fp 1 0 {"item_lock":{"mode":"lock_in_slot"}}