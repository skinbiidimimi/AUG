function off_pw
clear @s classico:chama_k 
clear @s classico:besta_k 
clear @s classico:dia_k 
clear @s classico:xlr8_k 
clear @s classico:massa_k 
clear @s classico:quatro_k 
clear @s classico:inseq_k 
clear @s classico:aqua_k 
clear @s classico:ultra_k 
clear @s classico:fanta_k 
clear @s classico:bala_k 
clear @s classico:sipo_k 
clear @s classico:lob_k 
clear @s classico:mumia_k 
clear @s classico:frank_k 
clear @s classico:iden_k 
clear @s classico:mega_k 
clear @s classico:glut_k 
clear @s classico:giga_k 
clear @s classico:feed_k 
clear @s classico:contra_k 
clear @s classico:fogo_k 
clear @s classico:eco_k 
clear @s classico:eno_k 
clear @s classico:arraia_k 
clear @s classico:fria_k 
clear @s classico:cro_k 
clear @s classico:atro_k 
clear @s classico:maca_k 
clear @s classico:gosma_k 
clear @s classico:alien_k 
clear @s classico:chocan_k 
clear @s classico:cosp_k 
clear @s classico:iguan_k 
clear @s classico:net 
clear @s classico:net2
clear @s classico:net3
clear @s classico:net4
clear @s classico:off 
clear @s classico:omnitrix_k
give @s classico:omnitrix_k

playsound omnitrix.des1 @a ~ ~ ~

particle ben:des ~ ~1 ~
particle ben:des ~ ~-1 ~
particle ben:des ~ ~ ~1
particle ben:des ~ ~1 ~-1
particle ben:des ~1 ~ ~
particle ben:des ~-1 ~ ~

replaceitem entity @s slot.armor.head 1 classico:omnitrix_k 1 0 {"item_lock":{"mode":"lock_in_slot"}}
