clear @s mal:chama
clear @s mal:diamante
clear @s mal:xlr8
clear @s mal:ultra
clear @s mal:fanta
clear @s mal:giga
clear @s mal:feed
clear @s mal:net
clear @s mal:net2
clear @s mal:off
clear @s o:maltrix
give @s mal:fogo 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s mal:eco 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s mal:eno 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s mal:cro 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s mal:atro 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s mal:gosma 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s mal:alien 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s mal:off 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s mal:net2 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.usar @a ~ ~ ~