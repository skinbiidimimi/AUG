function off_pw
function off_fp
clear @s nega:chama
clear @s nega:xlr8
clear @s nega:ultra
clear @s nega:feed
clear @s nega:iden
clear @s nega:fogo
clear @s nega:eco
clear @s nega:eno
clear @s nega:cromatico
clear @s nega:gosma
clear @s nega:x 
clear @s nega:nano
clear @s nega:podrao
clear @s nega:astro
clear @s nega:atomico
clear @s nega:net
clear @s nega:off
clear @s o:negatrix
give @s o:negatrix

playsound omnitrix.des3 @a ~ ~ ~

particle ben:des ~ ~1 ~
particle ben:des ~ ~-1 ~
particle ben:des ~ ~ ~1
particle ben:des ~ ~1 ~-1
particle ben:des ~1 ~ ~
particle ben:des ~-1 ~ ~

replaceitem entity @s slot.armor.head 1 o:negatrix 1 0 {"item_lock":{"mode":"lock_in_slot"}}