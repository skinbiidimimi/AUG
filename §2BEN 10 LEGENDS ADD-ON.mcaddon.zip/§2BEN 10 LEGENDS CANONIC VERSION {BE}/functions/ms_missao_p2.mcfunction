summon spw:missoes

dialogue open @e[type=spw:missoes,c=1] @p m_missoes3