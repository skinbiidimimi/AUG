function off_pw
function offc3
tp @s @e[type=zx:lap]
effect @e[type=spw:belicos_serena] instant_damage 99 9 true
clear @s o:offc3
clear @s alien:off
clear @s pw:talk

tp @e[type=zx:lap] 0 0 0

fill ~-20 ~100 ~-4 ~4 ~115 ~20 air