function off_pw
function off_fp
function supremo_2s
clear @s m:maca2
clear @s g:gosma2
clear @s a:alien2
clear @s b:bala3
clear @s g:glut3
clear @s g:giga3
clear @s n:nano2
clear @s n:nets
clear @s n:nets2
clear @s n:nets3
clear @s n:nets4
clear @s o:offc4
clear @s o:omnitrix3
replaceitem entity @s slot.armor.head 1 b:bala3s 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s pw:power_ball1 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s b:bala3 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s o:offc4 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tranaf @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans ~-1 ~ ~

effect @s invisibility infinite 1 true
effect @s jump_boost infinite 1 true
effect @s strength infinite 0 true
effect @s health_boost infinite 4 true
effect @s instant_health 1 10 true