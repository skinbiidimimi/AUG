kill spw:missoes
summon spw:vilgax

say derrote o vilgax!