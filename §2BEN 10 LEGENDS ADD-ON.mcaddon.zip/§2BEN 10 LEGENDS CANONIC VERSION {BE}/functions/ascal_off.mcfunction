clear @p ben:roupa_ascalon
clear @p a:modo_ascal_off
clear @p a:modo_ascal
clear @p esp:espada
give @p a:modo_ascal

effect @p clear
