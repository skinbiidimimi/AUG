summon spw:inicio

gamerule sendcommandfeedback false

dialogue open @e[type=spw:inicio,c=1] @p inicio

effect @e[type=spw:inicio] slowness 99 9 true