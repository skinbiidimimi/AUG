clear @s i:irado_giga
clear @s i:irado_feed
clear @s i:irado_eno
clear @s i:irado_cro
clear @s i:irado_atro
clear @s i:irado_gosma
clear @s i:irado_alien
clear @s i:irado_net
clear @s i:irado_net2
clear @s i:irado_off
clear @s o:omnitrix_irado
replaceitem entity @s slot.armor.head 1 i:irado_feed
give @s pw:power_raio 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s i:irado_off 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tran @a ~ ~ ~

particle ben:trans4 ~ ~1 ~
particle ben:trans4 ~ ~-1 ~
particle ben:trans4 ~ ~ ~1
particle ben:trans4 ~ ~1 ~-1
particle ben:trans4 ~1 ~ ~
particle ben:trans4 ~-1 ~ ~

effect @s invisibility infinite 10 true
effect @s jump_boost infinite 1 true
effect @s strength infinite 0 true
effect @s health_boost infinite 8 true
effect @s instant_health 2 25 true

replaceitem entity @s slot.weapon.offhand 1 zx:feed_fp 1 0 {"item_lock":{"mode":"lock_in_slot"}}