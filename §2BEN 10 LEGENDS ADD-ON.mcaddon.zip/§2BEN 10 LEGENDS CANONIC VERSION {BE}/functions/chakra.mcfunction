gamerule commandblockoutput false
gamerule sendcommandfeedback false

scoreboard objectives add chakra dummy

execute @a[tag=!join] ~ ~ ~ scoreboard players set @s chakra 1

execute @a[tag=!join] ~ ~ ~ tag @s add join
scoreboard players add @s chakra 0

title @s[scores={chakra=0}] actionbar §70
title @s[scores={chakra=1..10}] actionbar §4chakra1
title @s[scores={chakra=11..20}] actionbar §4chakra2
title @s[scores={chakra=31..40}] actionbar  §4chakra3
title @s[scores={chakra=41..50}] actionbar  §4chakra4
title @s[scores={chakra=51..60}] actionbar §4chakra5
title @s[scores={chakra=61..70}] actionbar  §4chakra6
title @s[scores={chakra=71..80}] actionbar  §4chakra7
title @s[scores={chakra=81..90}] actionbar  §4chakra8
title @s[scores={chakra=91..100}] actionbar  §4chakra9
give @p[scores={chakra=101..150}] zx:argila
scoreboard players set @s[scores={chakra=101..151}] chakra 0
