function off_pw
clear @s o:zombitrix
clear @s bz:bala
clear @s bz:mega
clear @s bz:mumia
clear @s bz:lob
clear @s bz:frank
clear @s bz:giga
clear @s bz:besouro
clear @s bz:af
clear @s bz:blox
clear @s bz:grava
clear @s bz:atro
clear @s bz:alien
clear @s bz:net
clear @s bz:off
give @s bz:af 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s bz:blox 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s bz:grava 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s bz:atro 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s bz:alien 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s bz:off 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.bzcar @a ~ ~ ~

replaceitem entity @s slot.armor.head 1 o:zombitrix 1 0 {"item_lock":{"mode":"lock_in_slot"}}