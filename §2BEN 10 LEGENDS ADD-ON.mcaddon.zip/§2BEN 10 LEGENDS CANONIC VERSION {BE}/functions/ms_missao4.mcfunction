kill spw:missoes
summon spw:hex
summon spw:feiticeira
summon spw:pet_pedra
summon spw:pet_pedra
summon spw:pet_pedra

say derrote o hex e sua sobrinha encatriz e os seus pets de pedras!