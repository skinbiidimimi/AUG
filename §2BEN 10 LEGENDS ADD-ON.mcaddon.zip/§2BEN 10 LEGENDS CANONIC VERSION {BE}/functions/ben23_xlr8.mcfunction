clear @s o:omnitrix23
clear @s ben23:chama
clear @s ben23:besta
clear @s ben23:diamante
clear @s ben23:xlr8
clear @s ben23:massa
clear @s ben23:quatro
clear @s ben23:inseq
clear @s ben23:off
clear @s ben23:net
clear @s ben23:net2
replaceitem entity @p slot.armor.head 1 ben23:xlr8 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @p v:v1 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @p pw:power_tornado 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @p ben23:off 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tran @a ~ ~ ~

particle ben:trans2 ~ ~1 ~
particle ben:trans2 ~ ~-1 ~
particle ben:trans2 ~ ~ ~1
particle ben:trans2 ~ ~1 ~-1
particle ben:trans2 ~1 ~ ~
particle ben:trans2 ~-1 ~ ~

effect @s haste infinite 90 true
effect @s invisibility infinite 10 true
effect @s jump_boost infinite 0 true
effect @s health_boost infinite 3 true
effect @s instant_health 1 10 true