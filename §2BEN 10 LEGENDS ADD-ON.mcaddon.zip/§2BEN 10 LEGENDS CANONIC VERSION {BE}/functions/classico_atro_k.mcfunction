clear @s classico:fogo_k 
clear @s classico:eco_k 
clear @s classico:eno_k 
clear @s classico:arraia_k 
clear @s classico:fria_k 
clear @s classico:cro_k 
clear @s classico:atro_k 
clear @s classico:net 
clear @s classico:net2
clear @s classico:net3
clear @s classico:net4
clear @s classico:off 
clear @s classico:omnitrix_k
replaceitem entity @s slot.armor.head 1 classico:atro_k 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s pw:power_atro 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s classico:off 1 0 {"item_lock":{"mode":"lock_in_slot"}}

playsound omnitrix.tran @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans ~-1 ~ ~

effect @s invisibility infinite 99 true
effect @s jump_boost infinite 2 true
effect @s health_boost infinite 4 true
effect @s instant_health 2 25 true

replaceitem entity @s slot.weapon.offhand 1 zx:atro_fp 1 0 {"item_lock":{"mode":"lock_in_slot"}}