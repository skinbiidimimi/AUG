particle ben:trans2 ~ ~1 ~
particle ben:trans2 ~ ~-1 ~
particle ben:trans2 ~ ~ ~1
particle ben:trans2 ~ ~1 ~-1
particle ben:trans2 ~1 ~ ~
particle ben:trans2 ~-1 ~ ~

playsound omnitrix.power @a ~ ~ ~