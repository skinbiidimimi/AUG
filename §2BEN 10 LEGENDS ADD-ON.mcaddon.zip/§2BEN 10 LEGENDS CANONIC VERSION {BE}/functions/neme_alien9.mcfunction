clear @s neme:alien8
clear @s neme:alien9
clear @s neme:alien10
clear @s neme:net
clear @s neme:off
clear @s o:nemetrix
replaceitem entity @s slot.armor.head 1 neme:alien9 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s neme:off 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tran @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans ~-1 ~ ~

effect @s invisibility infinite 10 true
effect @s jump_boost infinite 0 true
effect @s strength infinite 4 true
effect @s health_boost infinite 20 true
effect @s instant_health 1 10 true