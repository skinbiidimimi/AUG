clear @s albedo:maca
clear @s albedo:gosma
clear @s albedo:alien
clear @s albedo:bala
clear @s albedo:glut
clear @s albedo:giga
clear @s albedo:nano
clear @s albedo:net
clear @s albedo:net2
clear @s albedo:off
clear @s o:omnitrix2a
replaceitem entity @s slot.armor.head 1 albedo:gosma 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s pw:power_gosma1 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s albedo:off 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tranaf @a ~ ~ ~

particle off:particula ~ ~1 ~
particle off:particula ~ ~-1 ~
particle off:particula ~ ~ ~1
particle off:particula ~ ~1 ~-1
particle off:particula ~1 ~ ~
particle off:particula ~-1 ~ ~

effect @s slow_falling infinite 8 true
effect @s fire_resistance infinite 1 true
effect @s invisibility infinite 10 true
effect @s jump_boost infinite 1 true
effect @s regeneration infinite 1 true
effect @s health_boost infinite 2 true
effect @s instant_health 1 10 true

replaceitem entity @s slot.weapon.offhand 1 zx:gosma_fp 1 0 {"item_lock":{"mode":"lock_in_slot"}}