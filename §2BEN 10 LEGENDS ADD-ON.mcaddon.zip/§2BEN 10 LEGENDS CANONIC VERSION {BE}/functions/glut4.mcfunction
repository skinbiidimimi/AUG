clear @s b:frank4
clear @s i:iden4
clear @s m:mega_o4
clear @s g:glut4
clear @s g:giga4
clear @s f:feed
clear @s c:contra4
clear @s n:net40
clear @s n:net41
clear @s n:net42
clear @s n:net43
clear @s n:net44
clear @s n:net45
clear @s n:net46
clear @s n:net47
clear @s o:offd
clear @s o:omnitrix4
replaceitem entity @s slot.armor.head 1 g:glut4 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s pw:power_glut 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s o:offd 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tran @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans ~-1 ~ ~

effect @s invisibility infinite 99 true
effect @s jump_boost infinite 2 true
effect @s health_boost infinite 4 true
effect @s instant_health 2 25 true

replaceitem entity @s slot.weapon.offhand 1 zx:glut_fp 1 0 {"item_lock":{"mode":"lock_in_slot"}}