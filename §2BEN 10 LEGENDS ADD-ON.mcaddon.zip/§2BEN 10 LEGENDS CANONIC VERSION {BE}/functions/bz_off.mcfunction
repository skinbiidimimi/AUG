function off_pw
clear @s bz:bala
clear @s bz:mega
clear @s bz:mumia
clear @s bz:lob
clear @s bz:frank
clear @s bz:giga
clear @s bz:besouro
clear @s bz:af
clear @s bz:blox
clear @s bz:grava
clear @s bz:atro
clear @s bz:alien
clear @s bz:net
clear @s bz:off
clear @s o:zombitrix
give @s o:zombitrix

playsound omnitrix.bzoff @a ~ ~ ~

replaceitem entity @s slot.armor.head 1 o:zombitrix 1 0 {"item_lock":{"mode":"lock_in_slot"}}