clear @s o:maltrix
replaceitem entity @s slot.armor.head 1 o:maltrix 1 0 {"item_lock":{"mode":"lock_in_slot"}}

give @s mal:chama 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s mal:diamante 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s mal:xlr8 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s mal:ultra 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s mal:fanta 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s mal:giga 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s mal:feed 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s mal:off 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s mal:net 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.usar @a ~ ~ ~