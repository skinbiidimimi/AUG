clear @s o:omnitrix23
clear @s ben23:chama
clear @s ben23:besta
clear @s ben23:diamante
clear @s ben23:xlr8
clear @s ben23:massa
clear @s ben23:quatro
clear @s ben23:inseq
clear @s ben23:off
clear @s ben23:net
clear @s ben23:net2
clear @s ben23:net2
give @s ben23:aqua 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s ben23:ultra 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s ben23:fanta 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s[lm=1] ben23:bala 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s[lm=2] ben23:frank 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s[lm=3] ben23:mega 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s[lm=4] ben23:glut 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s ben23:off 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s[lm=5] ben23:net2 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

replaceitem entity @s slot.armor.head 1 o:omnitrix23 1 0 {"item_lock":{"mode":"lock_in_slot"}}

playsound omnitrix.car @a ~ ~ ~