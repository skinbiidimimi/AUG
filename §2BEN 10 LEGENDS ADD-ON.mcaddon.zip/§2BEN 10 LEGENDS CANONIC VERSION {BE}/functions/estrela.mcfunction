clear @s o:omnitrix2
clear @s o:offc3
clear @s n:netr
clear @s n:netr2
clear @s d:diamante2
clear @s e:estrela
clear @s r:rath
clear @s f:fanta2

replaceitem entity @s slot.armor.head 1 e:estrela 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s pw:power_estrela 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s o:offc3 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tranaf @a ~ ~ ~

particle on:particula ~ ~1 ~
particle on:particula ~ ~-1 ~
particle on:particula ~ ~ ~1
particle on:particula ~ ~1 ~-1
particle on:particula ~1 ~ ~
particle on:particula ~-1 ~ ~

effect @s invisibility infinite 10 true
effect @s jump_boost infinite 2 true
effect @s health_boost infinite 5 true
effect @s instant_health 2 25 true

replaceitem entity @s slot.weapon.offhand 1 zx:estrela_fp 1 0 {"item_lock":{"mode":"lock_in_slot"}}