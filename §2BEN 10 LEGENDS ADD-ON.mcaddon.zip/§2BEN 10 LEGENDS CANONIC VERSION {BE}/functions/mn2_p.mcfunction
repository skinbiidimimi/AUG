clear @p 
replaceitem entity @p slot.armor.head 1 id:menu3

say Selecione seu modo 

give @p id:menu3_s 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @p id:menu3_p 1 0 {"item_lock":{"mode":"lock_in_slot"}}