clear @s f:fogo
clear @s e:eco
clear @s e:eno
clear @s a:arraia
clear @s f:friagen 
clear @s c:cro
clear @s a:atro 
clear @s n:netr
clear @s n:netr2
clear @s o:offc3
clear @s o:omnitrix2
replaceitem entity @p slot.armor.head 1 f:fogo 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s pw:espinhos3 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @p o:offc3 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tranaf @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans ~-1 ~ ~

effect @s fire_resistance infinite 5 true
effect @s invisibility infinite 10 true
effect @s jump_boost infinite 0 true
effect @s strength infinite 1 true
effect @s regeneration infinite 0 true
effect @s health_boost infinite 5 true
effect @s instant_health 1 10 true

replaceitem entity @s slot.weapon.offhand 1 zx:fogo_fp 1 0 {"item_lock":{"mode":"lock_in_slot"}}