clear @s nega:eno
clear @s nega:cromatico
clear @s nega:gosma
clear @s nega:x 
clear @s nega:nano
clear @s nega:podrao
clear @s nega:astro
clear @s nega:atomico
clear @s nega:net
clear @s nega:off
clear @s o:negatrix
replaceitem entity @s slot.armor.head 1 nega:podrao 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s pw:power_podrao 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s nega:off 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
playsound omnitrix.tran @a ~ ~ ~

particle ben:trans3 ~ ~1 ~
particle ben:trans3 ~ ~-1 ~
particle ben:trans3 ~ ~ ~1
particle ben:trans3 ~ ~1 ~-1
particle ben:trans3 ~1 ~ ~
particle ben:trans3 ~-1 ~ ~

effect @s invisibility infinite 10 true
effect @s strength infinite 0 true
effect @s regeneration infinite 0 true
effect @s health_boost infinite 5 true
effect @s instant_health 1 10 true
