kill spw:missoes
summon spw:kevin_supremo

say kevin se trasformou em um uma nova mutação muito mais poderosa derrotek!