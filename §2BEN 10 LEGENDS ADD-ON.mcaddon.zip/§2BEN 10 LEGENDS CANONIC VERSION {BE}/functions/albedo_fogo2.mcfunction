function off_pw
clear @s albedo:fogo2 
clear @s albedo:eco2 
clear @s albedo:eno2 
clear @s albedo:arraia2 
clear @s albedo:friagen2 
clear @s albedo:cro2 
clear @s albedo:atro2 
clear @s albedo:nets 
clear @s albedo:nets2
clear @s albedo:nets3
clear @s albedo:nets4
clear @s albedo:off2 
clear @s o:omnitrix3a
replaceitem entity @s slot.armor.head 1 albedo:fogo2 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s pw:espinhos3 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s albedo:fogo2s 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s albedo:off2 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tranaf @a ~ ~ ~

particle off:particula ~ ~1 ~
particle off:particula ~ ~-1 ~
particle off:particula ~ ~ ~1
particle off:particula ~ ~1 ~-1
particle off:particula ~1 ~ ~
particle off:particula ~-1 ~ ~

effect @s fire_resistance infinite 5 true
effect @s invisibility infinite 10 true
effect @s jump_boost infinite 0 true
effect @s strength infinite 1 true
effect @s regeneration infinite 0 true
effect @s health_boost infinite 5 true
effect @s instant_health 1 10 true

replaceitem entity @s slot.weapon.offhand 1 zx:fogo_fp 1 0 {"item_lock":{"mode":"lock_in_slot"}}