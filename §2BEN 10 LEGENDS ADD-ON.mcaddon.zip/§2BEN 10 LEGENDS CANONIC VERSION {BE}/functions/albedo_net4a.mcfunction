function off_pw
clear @s albedo:fogo4a 
clear @s albedo:eco4a 
clear @s albedo:eno4a 
clear @s albedo:arraia4a 
clear @s albedo:fria4a 
clear @s albedo:cro4a 
clear @s albedo:atro4a 
clear @s albedo:net24a 
clear @s albedo:net34a 
clear @s albedo:net4a 
clear @s albedo:off4a 
clear @s o:omnitrix4a
give @s albedo:maca4a 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s albedo:gosma4a 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s albedo:alien4a 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s albedo:bala4a 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s albedo:glut4a 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s albedo:giga4a 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s albedo:nano4a 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s albedo:off4a 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s albedo:net24a 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.car3 @a ~ ~ ~
