function off_pw
function off_fp
clear @s albedo:fogo4a 
clear @s albedo:eco4a 
clear @s albedo:eno4a 
clear @s albedo:arraia4a 
clear @s albedo:fria4a 
clear @s albedo:cro4a 
clear @s albedo:atro4a 
clear @s albedo:maca4a
clear @s albedo:gosma4a
clear @s albedo:alien4a
clear @s albedo:bala4a
clear @s albedo:glut4a
clear @s albedo:giga4a
clear @s albedo:nano4a
clear @s albedo:diamante4a
clear @s albedo:estrela4a
clear @s albedo:rath4a
clear @s albedo:ame4a
clear @s albedo:amf4a
clear @s albedo:arma4a
clear @s albedo:tarta4a
clear @s albedo:nrg4a
clear @s albedo:blox4a
clear @s albedo:grava4a
clear @s albedo:astro4a
clear @s albedo:cocor4a
clear @s albedo:atomico4a
clear @s albedo:podrao4a
clear @s albedo:vomp4a
clear @s albedo:net4a 
clear @s albedo:net24a 
clear @s albedo:net34a 
clear @s albedo:off4a 
clear @s o:omnitrix4a
give @s o:omnitrix4a

playsound omnitrix.des3 @a ~ ~ ~

particle ben:des ~ ~1 ~
particle ben:des ~ ~-1 ~
particle ben:des ~ ~ ~1
particle ben:des ~ ~1 ~-1
particle ben:des ~1 ~ ~
particle ben:des ~-1 ~ ~