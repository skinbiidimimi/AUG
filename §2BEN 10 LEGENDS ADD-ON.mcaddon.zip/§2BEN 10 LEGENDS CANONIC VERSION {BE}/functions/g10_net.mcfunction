function off_pw
clear @s g10:chama
clear @s g10:besta
clear @s g10:dia
clear @s g10:xlr8
clear @s g10:massa
clear @s g10:quatro
clear @s g10:inseq
clear @s g10:net
clear @s g10:off
clear @s o:omniguen
give @s g10:aqua 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s g10:ultra 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s g10:fanta 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s[lm=3] g10:bala 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s[lm=6] g10:sipo 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s[lm=12] g10:giga 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s[lm=15] g10:gosma 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s[lm=20] g10:alien 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s g10:off 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.car @a ~ ~ ~

replaceitem entity @s slot.armor.head 1 o:omniguen 1 0 {"item_lock":{"mode":"lock_in_slot"}}
