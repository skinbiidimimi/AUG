clear @s b:frank
clear @s g:glut
clear @s i:iden
clear @s m:mega_o
clear @s g:gigante
clear @s f:feed1
clear @s c:contra
clear @s o:omnitrix
clear @s o:offc2
clear @s n:net2
replaceitem entity @s slot.armor.head 1 b:frank 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s pw:power_raio 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s o:offc2 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tran @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans ~-1 ~ ~

effect @s invisibility infinite 10 true
effect @s jump_boost infinite 2 true
effect @s strength infinite 0 true
effect @s health_boost infinite 8 true
effect @s instant_health 2 25 true

replaceitem entity @s slot.weapon.offhand 1 zx:frank_fp 1 0 {"item_lock":{"mode":"lock_in_slot"}}