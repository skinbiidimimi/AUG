clear @s c:chama
clear @s b:besta
clear @s d:diamante
clear @s x:xlr8
clear @s m:massa
clear @s q:quatro
clear @s a:aquatico
clear @s i:inseq
clear @s f:fanta
clear @s o:omnitrix
clear @s o:offc2
clear @s n:net
replaceitem entity @p slot.armor.chest 1 elytra

replaceitem entity @p slot.armor.head 1 i:inseq 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @p pw:gosma_acido 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @p o:offc2 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tran @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans ~-1 ~ ~

effect @s invisibility infinite 10 true
effect @s jump_boost infinite 1 true
effect @s strength infinite 0 true
effect @s health_boost infinite 2 true
effect @s instant_health 1 10 true
