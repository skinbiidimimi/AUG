clear @p o:omnitrix2a
clear @p albedo:fogo
clear @p albedo:eco
clear @p albedo:eno
clear @p albedo:arraia
clear @p albedo:friagen
clear @p albedo:cro
clear @p albedo:atro
clear @p albedo:maca
clear @p albedo:gosma
clear @p albedo:alien
clear @p albedo:off
clear @p albedo:net
replaceitem entity @p slot.armor.feet 1 f:friagen_asas 1 0 {"item_lock":{"mode":"lock_in_slot"}}

replaceitem entity @p slot.armor.head 1 albedo:friagen 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @p albedo:off 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tranaf @a ~ ~ ~

particle off:particula ~ ~1 ~
particle off:particula ~ ~-1 ~
particle off:particula ~ ~ ~1
particle off:particula ~ ~1 ~-1
particle off:particula ~1 ~ ~
particle off:particula ~-1 ~ ~

effect @s slow_falling infinite 9 true
effect @s invisibility infinite 10 true
effect @s jump_boost infinite 1 true
effect @s health_boost infinite 4 true
effect @s instant_health 2 25 true

replaceitem entity @s slot.weapon.offhand 1 zx:fria_fp 1 0 {"item_lock":{"mode":"lock_in_slot"}}