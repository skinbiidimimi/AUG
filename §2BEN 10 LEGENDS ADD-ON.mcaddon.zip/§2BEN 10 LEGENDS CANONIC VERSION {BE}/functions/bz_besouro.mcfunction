clear @s bz:bala
clear @s bz:mega
clear @s bz:mumia
clear @s bz:lob
clear @s bz:frank
clear @s bz:giga
clear @s bz:besouro
clear @s bz:net
clear @s bz:off
clear @s o:zombitrix
replaceitem entity @s slot.armor.head 1 bz:besouro 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s pw:power_glut 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s bz:off 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.bztran @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans ~-1 ~ ~

effect @s invisibility infinite 99 true
effect @s jump_boost infinite 2 true
effect @s health_boost infinite 5 true
effect @s instant_health 2 25 true

replaceitem entity @s slot.weapon.offhand 1 zx:besouro_fp 1 0 {"item_lock":{"mode":"lock_in_slot"}}