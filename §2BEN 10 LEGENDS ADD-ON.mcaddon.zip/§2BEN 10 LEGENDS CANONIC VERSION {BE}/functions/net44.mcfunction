function off_pw
clear @s m:maca4
clear @s g:gosma4
clear @s a:alien4
clear @s g:glut5
clear @s n:nano4
clear @s r:rath4
clear @s e:estrela4
clear @s n:net40
clear @s n:net41
clear @s n:net42
clear @s n:net43
clear @s n:net44
clear @s n:net45
clear @s n:net46
clear @s n:net47
clear @s o:offd
clear @s o:omnitrix4
give @s[lm=77] a:ame4 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s[lm=80] a:amf4 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s[lm=80] a:arma4 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s[lm=80] t:tarta4 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s[lm=80] n:nrg4 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s[lm=80] a:ace4 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s c:chamalien4 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s o:offd 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s[lm=80] n:net45 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.usar @a ~ ~ ~
