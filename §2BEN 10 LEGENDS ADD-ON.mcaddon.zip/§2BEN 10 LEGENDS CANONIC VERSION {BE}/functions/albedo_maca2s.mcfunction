function off_pw
clear @s albedo:maca2
clear @s albedo:maca2s
clear @s albedo:gosma2
clear @s albedo:alien2
clear @s albedo:nets
clear @s albedo:nets2
clear @s albedo:nets3
clear @s albedo:nets4
clear @s albedo:off2
clear @s o:omnitrix3a
replaceitem entity @p slot.armor.head 1 albedo:maca2s 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @p albedo:maca2 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @p albedo:off2 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tranaf @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans ~-1 ~ ~

effect @s slow_falling infinite 9 true
effect @s invisibility infinite 99 true
effect @s jump_boost infinite 2 true
effect @s strength infinite 1 true
effect @s health_boost infinite 6 true
effect @s instant_health 2 25 true

