particle ben:cores ~ ~1 ~
particle ben:cores ~ ~-1 ~
particle ben:cores ~ ~ ~1
particle ben:cores ~ ~1 ~-1
particle ben:cores ~1 ~ ~
particle ben:cores ~-1 ~ ~