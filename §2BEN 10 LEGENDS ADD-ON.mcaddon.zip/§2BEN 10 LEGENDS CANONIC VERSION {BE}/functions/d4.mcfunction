clear @s o:offd3
clear @s o:offd4
clear @s o:offd2
clear @s o:bioomnitrix
replaceitem entity @s slot.armor.head 1 o:bioomnitrix

give @s c:chama4k 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s b:besta4k 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s d:diamante4k 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s x:xlr84k 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s m:massa4k 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s q:quatro4k 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s i:inseq4k 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s o:offd2 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s n:net4k 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.usar @a ~ ~ ~