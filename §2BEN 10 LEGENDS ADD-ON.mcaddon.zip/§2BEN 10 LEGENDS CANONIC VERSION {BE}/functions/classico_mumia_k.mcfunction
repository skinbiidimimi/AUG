clear @s classico:aqua_k 
clear @s classico:ultra_k 
clear @s classico:fanta_k 
clear @s classico:bala_k 
clear @s classico:sipo_k 
clear @s classico:lob_k 
clear @s classico:mumia_k 
clear @s classico:net 
clear @s classico:net2
clear @s classico:net3
clear @s classico:net4
clear @s classico:off 
clear @s classico:omnitrix_k
replaceitem entity @s slot.armor.head 1 classico:mumia_k 1 0 {"item_lock":{"mode":"lock_in_slot"}}
give @s pw:power_mumia 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}
give @s classico:off 1 0 {"item_lock":{"mode":"lock_in_inventory"},"keep_on_death":{}}

playsound omnitrix.tran @a ~ ~ ~

particle ben:trans ~ ~1 ~
particle ben:trans ~ ~-1 ~
particle ben:trans ~ ~ ~1
particle ben:trans ~ ~1 ~-1
particle ben:trans ~1 ~ ~
particle ben:trans ~-1 ~ ~

effect @s invisibility infinite 10 true
effect @s jump_boost infinite 1 true
effect @s health_boost infinite 3 true
effect @s instant_health 1 10 true

replaceitem entity @s slot.weapon.offhand 1 zx:mumia_fp 1 0 {"item_lock":{"mode":"lock_in_slot"}}